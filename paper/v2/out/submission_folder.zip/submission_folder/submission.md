---
layout: distill
title: 'A pre-registered test of training on co-occurring versus isolated stressors in a multi-agent fire environment'
description: 'A pre-registered test of whether training a single policy on co-occurring stressors beats training it on each in isolation, in the Compound Hostile Environment (CHE), a multi-agent environment where a fire burns in every episode.'
date: 2026-10-11
htmlwidgets: true
authors:
  - name: Anonymous
    affiliations:
      name: Anonymous
bibliography: submission.bib
toc:
  - name: "1 Introduction"
  - name: "2 Related work"
  - name: "3 The environment"
  - name: "4 Severity calibration"
  - name: "5 Coupling A: collapse seeds the fire"
  - name: "6 Coupling B: smoke attenuates perception"
  - name: "7 Communication denial: inert under this encoder at this scale"
  - name: "8 Methodology: bars come with floors"
  - name: "9 The pre-registered compositional test"
  - name: "10 Limitations"
  - name: "11 Reproducibility"
  - name: "Appendices"
_styles: >-
  .print-companion { display: none; } @media print { .print-companion { display: block; } d-article figure iframe { display: none; } .interact { display: none; } } d-article div.highlighter-rouge pre { font-size: 12px; line-height: 1.5; white-space: pre; overflow-x: auto; } d-article div.highlighter-rouge pre code { font-size: inherit; white-space: inherit; } @media (min-width: 1000px) { d-article > div.highlighter-rouge { grid-column: page; } } @media print { d-article div.highlighter-rouge pre { white-space: pre-wrap; overflow-wrap: anywhere; overflow-x: visible; } } d-article mjx-container[display="true"] { overflow-x: auto; overflow-y: hidden; max-width: 100%; } @media print { d-article > table, d-article > span:has(> mjx-container[display="true"]), d-article > div.highlighter-rouge { grid-column: page; } d-article table { display: table; overflow: visible; width: 100%; table-layout: auto; } d-article table th, d-article table td { font-size: 10px; line-height: 1.35; padding: 1px 4px; overflow-wrap: break-word; } d-article table code { white-space: normal; overflow-wrap: anywhere; font-size: 9px; } d-article mjx-container[display="true"] { overflow: visible !important; } d-article div.highlighter-rouge pre { font-size: 9px; } } d-article iframe[src$="/explorer_thetastar_random_seed0.html"], d-article iframe[src$="/explorer_thetastar_iso_s1_T1000_ep0.html"], d-article iframe[src$="/explorer_thetastar_joint_s1_T1000_ep0.html"] { height: 1360px !important; } @media (min-width: 768px) { d-article iframe[src$="/explorer_thetastar_random_seed0.html"], d-article iframe[src$="/explorer_thetastar_iso_s1_T1000_ep0.html"], d-article iframe[src$="/explorer_thetastar_joint_s1_T1000_ep0.html"] { height: 1248px !important; } } @media (min-width: 1000px) { d-article iframe[src$="/explorer_thetastar_random_seed0.html"], d-article iframe[src$="/explorer_thetastar_iso_s1_T1000_ep0.html"], d-article iframe[src$="/explorer_thetastar_joint_s1_T1000_ep0.html"] { height: 764px !important; } } @media (min-width: 1180px) { d-article iframe[src$="/explorer_thetastar_random_seed0.html"], d-article iframe[src$="/explorer_thetastar_iso_s1_T1000_ep0.html"], d-article iframe[src$="/explorer_thetastar_joint_s1_T1000_ep0.html"] { height: 700px !important; } } d-article p.caption { font-size: 13px; line-height: 1.5; color: rgba(0, 0, 0, 0.6); } d-article table { display: block; overflow-x: auto; }
---



We report a pre-registered test of whether training one policy on co-occurring stressors beats training it on each in isolation, in the Compound Hostile Environment (CHE), a pure-JAX multi-agent environment where a cellular-automaton fire burns in every episode.<d-footnote>We used the LLM assistant Claude under our direction; its uses included drafting design documents and reviews, proposing options for our decisions, writing and running code and analyses, making figures, helping with literature search and citations, and drafting this text from our records. The authors are responsible for every word.</d-footnote> Two stressors are coupled to the fire: structural collapse can add ignitions, and smoke attenuates perception by Beer–Lambert transmittance; a third, communication denial, is independent. Joint and isolated training are run at matched compute and evaluated at a held-out near-critical severity, with task completion and survival as Šidák-corrected co-primaries. We ran 72 seeds per arm, above the registered cap of 60, a recorded deviation made before unblinding.

Joint training raises survival by 0.96 points (Šidák-corrected 95 % CI [+0.47, +1.44]); completion shows no detectable change (−1.73 points, CI [−4.12, +0.66]), which excludes a joint-training gain larger than 0.66 points. Both differences are sign unstable over the final half of training: the survival gap opens only in the last fifth, and completion leans negative from 70 % of the budget. The survival gain does not survive the inert-share correction. Communication denial, inert under a frozen random-projection encoder at this scale, is the only stressor in a third of the isolated arm's training episodes, which are thus fire-only in effect. This is our design error: we kept a stressor already found inert and did not count the fire-only share it created; found before the main training runs, the bias was registered with its correction while they ran, before unblinding. The correction is a 20-seed sensitivity arm without those episodes, outside the two confirmatory tests; joint training's survival differs from that arm's by −0.03 points (Šidák-corrected CI [−0.68, +0.63]), though it still sees each coupling twice as often, always combined.

The fire is an ambient hazard that no reward, cost or constraint channel reads; the reward reads only task variables and agent deaths, pricing every death the same. Severity is set relative to a measured percolation threshold; each stressor is a parameter of one transition or observation kernel, and switching it off reproduces the nested model's trajectories bit for bit. We describe a measurement protocol with reproducibility floors per metric, per GPU and per artifact. We recommend, from this single environment, that studies of compositional generalization match the share of training with an active stressor before attributing a gain to composition.



<figure class="l-page">
  <iframe src="{{ 'assets/html/submission/explorer_thetastar_random_seed0.html' | relative_url }}" width="100%" height="700" style="border:none" title="Episode explorer: one random-policy episode of CHE at the held-out configuration" loading="lazy"></iframe>
  <figcaption><strong>Figure 1.</strong> One episode of CHE. The map is environment state: fire, the smoke field ρ, weak and collapsed floor, food, agents alive and dead, and ignitions seeded by collapse. Only the selected agent's three panels concern perception: its observation as produced (labelled obs v3, the masking observation), those cells' true state, for comparison, and P(seen) = τ, the transmittance through smoke. The held-out configuration θ&#42;, episode key, policy and stochastic actions were fixed before rendering. <span class="figure-note">Status: illustrative · random policy · grades nothing · Interact: play, scrub, jump to events, toggle layers, pick agents.</span></figcaption>
</figure>

<div class="print-companion">
{% include figure.html path="assets/img/submission/explorer_thetastar_random_seed0_static.png" class="img-fluid" alt="Three map frames of one random-policy episode, at its start, middle and end, showing fire state, smoke density, weak and collapsed floor, collapse-seeded ignitions, food and agents, with one selected agent's observation, the true state of the same cells, and the probability that each cell was seen." caption="Static companion of Figure 1 for the printed PDF." %}
</div>

Captions carry a status. Recurring statuses: illustrative (grades nothing); registered (read by a rule fixed before unblinding); sensitivity arm (outside the two confirmatory tests); secondary (carries no verdict); descriptive (no test); reference scale (cross-artifact), a spread measured on other runs, shown for scale only.


## 1 Introduction


When a training distribution has to cover several stressors, its designer chooses whether the policy meets them together or one at a time. Ecology studies the interactive and cumulative effects of multiple stressors <d-cite key="crain2008stressors,cote2016stressors"></d-cite>, and climate science the risk from compound events <d-cite key="zscheischler2018compound,zscheischler2020typology"></d-cite>. In reinforcement learning the choice is a question of zero-shot generalization <d-cite key="kirk2023zsg"></d-cite>: must a policy see stressors co-occur in training to cope with their co-occurrence at test time? Gao et al. (2024) <d-cite key="gao2024composition"></d-cite> studied it for imitation-learned manipulation; we study it in multi-agent reinforcement learning, for survival and task completion under a lethal fire.

Where the hazard sits in the learning problem shapes what such a comparison can teach: in some fire-related work it is the task <d-cite key="haksar2018"></d-cite>, and safe reinforcement learning typically places it in a cost or a constraint <d-cite key="garcia2015safe"></d-cite>. In the Compound Hostile Environment (CHE) the fire is an *ambient hazard* (Definition 2 in §3): a fixed stochastic process that optimizes against no one and enters no reward, cost or constraint channel. The reward reads task variables and agent deaths, and prices every death at $d_p = 0.5$, whatever its cause. No reward or cost signal mentions the hazard in either arm; the agents meet the fire only through what they observe and what happens to them. Proposition 1 shows that the fire, which looks like nonstationarity to any one agent, is part of the state: CHE is a well-defined Dec-POMDP whose states reachable within the horizon form a finite set (§3).

CHE is written in pure JAX, and a cellular-automaton fire burns in every episode (Figure 1). For the idealized kernel the burnt region is exactly a bond-percolation cluster (Proposition 2) <d-cite key="grassberger1983,kesten1980"></d-cite>, and the three severities place the fire's transmissibility β below, near and above a *measured* percolation threshold of the implemented kernel (§4). Two stressors are coupled to the fire: collapse can add ignitions (Coupling A, of strength $\kappa_A$; §5), and smoke attenuates each agent's egocentric observation by Beer–Lambert transmittance (Coupling B, $\kappa_B$; §6). A third, link denial at level δ, is independent of it (§7); $\theta = (\beta, \kappa_A, \kappa_B, \delta)$ is the environment configuration.

The training question becomes a pre-registered test of two training mixtures (Figure 2).

<figure class="l-page">
  <iframe src="{{ 'assets/html/submission/composer_training_mixtures.html' | relative_url }}" width="100%" height="442" style="border:none" title="Training mixtures of ISO, ISO-4 and JOINT by episode type" loading="lazy"></iframe>
  <figcaption><strong>Figure 2.</strong> What each arm trained on. Each bar splits one arm's training mixture into episode types: Coupling A only, Coupling B only, both together, and fire-only. Beneath each bar are each coupling's frequency (labelled “per-stressor marginal” on the figure) and the active share. ISO-4 is ISO without its δ-only components. The figure shows configured shares, read from the training configs, and cannot show outcomes, trained behaviour or predictions. <span class="figure-note">Status: configuration facts · grades nothing · Interact: count δ-only episodes as inert (default; §7) or nominally; split by β; hover a segment; table view.</span></figcaption>
</figure>

<div class="print-companion">
{% include figure.html path="assets/img/submission/composer_training_mixtures.png" class="img-fluid" alt="Stacked bars of the three training mixtures by episode type, with each arm's per-coupling frequencies and the share of episodes that carry an active stressor." caption="Static companion of Figure 2 for the printed PDF." %}
</div>

An isolated arm (ISO) trains one policy on single-stressor configurations and a joint arm (JOINT) one on configurations with every stressor on, both at β = 0.43 and 0.70. Both are evaluated at θ\*, every stressor on at the near-critical β = 0.49, which neither saw. Architecture, hyperparameters, evaluation draw and compute (1000 updates) are matched, with one shared-parameter IPPO policy per training seed <d-cite key="dewitt2020ippo"></d-cite>. The estimand is the compositional gap Γ, JOINT's mean minus ISO's at θ\*, on two co-primary outcomes, task completion and survival, Šidák-corrected for m = 2 tests. Four outcome branches, a framing for each and a falsifier were registered on 2026-08-13, before the grid began (a fifth was added before unblinding, the first computation of any outcome contrast; Appendix E). We ran 72 seeds per arm, above the registered cap of 60, a recorded deviation made before unblinding (§9.1).

JOINT sees each coupling three times as often as ISO, so the endpoints differ in frequency as well as in co-occurrence. A secondary sweep in the spirit of DBCA <d-cite key="keysers2020"></d-cite> varies co-occurrence at fixed frequency, but its fire-only share rises with co-occurrence, and it bears no verdict (§9.1). Communication denial is inert under our frozen message encoder at this scale (§7), so the composition tested is that of the two couplings, and the third of ISO's training episodes that carry only δ are fire-only. ISO's *active share*, the fraction of training episodes with a behaviourally active stressor, is therefore two thirds, and JOINT's is one. This is an error in our design: it left δ out of the secondary sweeps because δ was inert, yet kept it in ISO's mixture, and did not count the fire-only episodes that resulted. A review of the registered design identified the bias on 2026-08-16, before the grid; we registered it, its direction, and a correcting arm, ISO-4, with its reading rule on 2026-09-18, mid-grid and before unblinding (§9.1). At the test's severity Coupling B was behaviourally quiet in calibration: its own survival effect was within the spread over three seeds (§6.4), and none of the three severities has both couplings strongly live (§10).

<figure class="l-page">
  <iframe src="{{ 'assets/html/submission/opening_ladder.html' | relative_url }}" width="100%" height="427" style="border:none" title="Registered readings: Γ and Γ₄ on survival and completion" loading="lazy"></iframe>
  <figcaption><strong>Figure 3.</strong> Survival: Γ REJECT; the gain “does not survive the inert-share correction” (Γ₄ null). Completion: Γ null; Γ₄ null, a second exclusion bound. Γ is JOINT − ISO, the registered test; Γ₄, the corrected gap, is JOINT − ISO-4, where ISO-4 is a sensitivity arm outside the confirmatory family. X₄, on the completion row, is Γ₄'s minimum detectable effect at 80 % power. The text quotes the printed rate differences × 100, as points. On the figure “unit 1” is GPU 1, “cross-unit” means across GPUs, and “full ladder: §9.2” points to Figure 11. The figure cannot show how Γ moved during training (sign unstable over the final half; Figure 12). <span class="figure-note">Status: registered for Γ · sensitivity arm for Γ₄ · Interact: none.</span></figcaption>
</figure>

<div class="print-companion">
{% include figure.html path="assets/img/submission/opening_ladder.png" class="img-fluid" alt="Joint minus isolated training and joint minus ISO-4, for survival and completion, each with its Šidák-corrected interval and registered verdict; the survival gain is shown beside the ISO-4 contrast, labelled does not survive the inert-share correction." caption="Static companion of Figure 3 for the printed PDF." %}
</div>

At θ\*, joint training raises survival by 0.96 points (Šidák-corrected 95 % CI [+0.47, +1.44]; points are rate differences × 100), and the survival test rejects (Figure 3). Task completion shows no detectable change, −1.73 points (CI [−4.12, +0.66]), which excludes a joint-training gain larger than 0.66 points. The founding hypothesis, that joint training improves both outcomes, did not occur. The falsifier registered for an asymmetric outcome passes (§9.2); under Definition 2 the asymmetry lies between a penalized channel, deaths, and a rewarded one, the task. Both co-primaries are sign unstable over the final half of training: the survival gap opens only in the last fifth of the budget, and completion leans negative from 70 % of it onward (Figure 12).

The survival gain does not survive the inert-share correction. ISO-4, ISO without its δ-only components, is a sensitivity arm outside the confirmatory family, trained with 20 seeds on a second GPU; its survival is 0.98 points above ISO's, an estimate with no registered test. The corrected gap Γ₄, JOINT − ISO-4, is −0.03 points (Šidák-corrected 95 % CI [−0.68, +0.63]), although JOINT still sees each coupling twice as often as ISO-4 and always in combination. A same-GPU replicate, proposed after Γ₄ was seen, agrees. The correction excludes only a large composition effect, and ISO-4 changes the active share and each coupling's frequency together; §9.2 states both limits, what the secondary design adds and where its fit fails.

A joint-versus-isolated comparison that leaves the active share free can report an active-share effect as a composition effect (§9.3). In the search described in §2 we found no reinforcement-learning comparison that trains its isolated arm on a mixture of single stressors and matches that arm to the joint one on this share. We claim no convergence guarantee and no survival gap robust to the training budget: every comparison is at matched compute. Nor do we claim a theorem that joint training wins; Proposition 4 (§9.1), a transfer bound for a fixed policy, bounds only what isolated training can be guaranteed to transfer.

Our contributions are:

1. CHE, an environment built as an instrument, with severity by measured dynamical phase, bitwise-exact nested ablations and theory that doubles as unit tests (§3–§7).
2. Calibration findings that stand without the training comparison. Under the calibration's trained policies, collapse-seeded ignitions fall 4.8-fold from low to high severity, a fall the random-policy calibration had already shown before any trained policy was measured (§5). Smoke costs survival at high severity, in the same direction in three of three replicates (§6), and communication denial is inert under the frozen encoder (§7). Under the measurement protocol of §8, acceptance bars come with floors measured per metric, per GPU and per artifact, and the bars that lack one are named.
3. A pre-registered test of joint against isolated training (§9), whose survival advantage does not survive the inert-share correction, which was registered before unblinding.


## 2 Related work


Table 1 sets the nearest fire-related and safety-related work beside CHE.

**Table 1.** Where the hazard enters the learning or planning problem.

| work | agents and method | where the hazard enters |
|---|---|---|
| Haksar & Schwager (2018) <d-cite key="haksar2018"></d-cite> | aerial agents fighting wildfire; multi-agent deep Q-network | **the task**: a reward for moving to burning trees on the fire's boundary (their Algorithm 2); the paper gives the fire no way to harm the agents |
| JaxWildfire (Çakır et al., 2025) <d-cite key="cakir2025jaxwildfire"></d-cite> | one air-tanker agent; JAX cellular-automaton wildfire simulator | **the reward**, hazard-priced: a per-step penalty proportional to the number of burning cells, with a bonus for full extinction; harm to the agent is not described |
| safe reinforcement learning, as García & Fernández (2015) define it <d-cite key="garcia2015safe"></d-cite> | learning policies that maximize return while ensuring reasonable system performance and/or respecting safety constraints | **a constraint or a cost**, typically |
| VULCAN (Liu & Yan, 2026) <d-cite key="liu2026vulcan"></d-cite> | a proposed approach to multi-robot fire search and rescue, planned by a vision-language model rather than learned | **a hazard cost map** that folds in smoke, heat and sensing uncertainty |
| CHE (this paper) | 12 agents; independent PPO | **ambient**: the transition and observation kernels only; no reward, cost or constraint reads the fire, and the reward prices each death at $d_p = 0.5$, whatever its cause |

CHE's reward is hazard-blind, while JaxWildfire's is hazard-priced: ours prices an outcome, each death the same (Definition 2 in §3.3). VULCAN's preliminary evaluation covers baselines only, and its evaluation metric, cumulative hazard exposure, is also abbreviated CHE, unrelated to our environment's name.

Coupling A lets structural collapse add ignitions. The nearest neighbour we found is Raut et al. (2026) <d-cite key="raut2026psps"></d-cite>, who model public-safety power shutoffs as a single-agent decision problem. In it, the power flows that follow from the operator's switching decisions set the failure probability of lines in wildfire areas, which the authors treat as ignition risk. Their reward is negative operating cost, and there is no spatial spread model. CHE's agents influence the hazard too, but weakly and indirectly: an agent standing on a weak cell raises that cell's collapse rate, yet most collapses happen with no agent present (§5.1). A collapse may then seed fire, so we do not claim that CHE's hazard grows without agent influence. The difference from Raut et al. is one of directness and size: there the controlled decision sets the failure probability, while in CHE ignition is not an action available to the agents.

Coupling B attenuates each agent's observation by Beer–Lambert transmittance along the line of sight through smoke. VULCAN degrades simulated sensing with smoke density and visibility loss, and infers smoke density from image degradation and depth consistency, but it has no transmittance model. JaxWildfire's observations are partial and egocentric but not attenuated. In the search described below, we found no reinforcement-learning environment whose observation kernel attenuates by transmittance.

CHE follows JaxMARL's environment conventions <d-cite key="rutherford2024jaxmarl"></d-cite> and trains with independent PPO <d-cite key="dewitt2020ippo"></d-cite>. Among the JAX multi-agent benchmarks we surveyed, JaxMARL, Multi-Agent Craftax <d-cite key="alomari2025macraftax"></d-cite> and Assistax <d-cite key="hinckeldey2025assistax"></d-cite>, none has an evolving, spreading lethal hazard field or perception attenuated by a hazard. Multi-Agent Craftax comes closest in kind: its agents lose health to hunger and enemies and can die, but its lava is static terrain that agents cannot enter. In Crafter and in Craftax-Classic, the JAX reimplementation described alongside Craftax, lava is lethal, and Crafter and Craftax reward each health point regained and penalize each one lost <d-cite key="hafner2022crafter,matthews2024craftax"></d-cite>, pricing an outcome, as our reward does. POBAX <d-cite key="tao2025pobax"></d-cite> is a single-agent suite for partial observability, and BenchMARL <d-cite key="bettini2024benchmarl"></d-cite> a multi-agent benchmarking library built on TorchRL.

Domain randomization trains on a broad, fixed distribution over simulator parameters so that the deployed setting looks like one more sample <d-cite key="tobin2017dr,muratore2022drreview"></d-cite>. Unsupervised environment design adapts the distribution to the learner instead. PAIRED generates environments from a regret objective <d-cite key="dennis2020paired"></d-cite>; Prioritized Level Replay revisits levels by their estimated learning potential <d-cite key="jiang2021plr"></d-cite> and was later recast as environment design <d-cite key="jiang2021robustplr"></d-cite>; and ACCEL evolves levels near the frontier of the agent's ability <d-cite key="parkerholder2022accel"></d-cite>. These methods ask which distribution to train on, usually adaptively; we compare two fixed distributions and evaluate no adaptive curriculum (§10).

The closest earlier study of our question is Gao et al. (2024) <d-cite key="gao2024composition"></d-cite>. In visual imitation learning for robotic manipulation, they ask whether policies compose environmental factors, such as object type and position, table texture and height, and camera position, to succeed on unseen combinations. They compare data-collection strategies at a matched number of demonstrations, among them varying one factor at a time and cycling through factors so that more combinations appear (their §III-C and §IV-A). Policies do compose, more weakly when both factors are physical (their §V-B), and the strategy that cycles through factors is generally the most effective, which the authors hypothesize is due to the combinations it covers. Their design is built for data efficiency and does not separate co-occurrence from how often each factor value appears. CompoSuite <d-cite key="mendez2022composuite"></d-cite> studies the composition of tasks, over robots, objects, objectives and obstacles, in multi-task reinforcement learning. The DBCA method <d-cite key="keysers2020"></d-cite> builds splits whose atom distributions are similar and whose compound distributions differ. Our secondary sweep follows that idea, holding each coupling's frequency fixed while co-occurrence varies; our ISO and JOINT endpoints do not, since JOINT sees each coupling three times as often as ISO (§1, §9.1).

Robust reinforcement learning asks the same question about perturbations. Erdem & Üre (2025) <d-cite key="erdem2025mixed"></d-cite> train single-agent continuous-control policies against a learned adversary that perturbs observations, actions, or both, and report that agents trained against one modality remain vulnerable to simultaneous attacks on both (their Tables 3–4). Under single-type attacks, agents trained against their balanced mixed adversary do at least as well as those trained against a naive one in all six cells, one a tie (their Table 5). Of their six training arms, one is an unattacked baseline; in each of the others an attack is computed at every step (their Algorithm 1). No attacked arm schedules clean steps, so none has a counterpart of the fire-only share our correction removes. No arm trains on a mixture of single-type attacks, and the mixed arms carry the combined budget, which the authors note is more severe. Their design thus bundles per-modality frequency, co-occurrence and a larger budget, which is nearer to what our corrected contrast leaves in, where JOINT still sees each coupling twice as often as ISO-4; it neither supports nor contradicts our corrected null. Agrawal et al. (2023) <d-cite key="agrawal2023multimodal"></d-cite> train multi-agent policies against random reward, state and action noise, one or two types at a time, under a curriculum that raises the noise level and sets training length, so exposure differs between their models. In supervised vision, Tramèr & Boneh (2019) <d-cite key="tramer2019multiple"></d-cite> and Hsiung et al. (2023) <d-cite key="hsiung2023compositional"></d-cite> study robustness to multiple and to composite perturbations.

Chen et al. (2022) <d-cite key="chen2022understandingdr"></d-cite> model domain randomization as returning the optimal history-dependent policy of a latent MDP, a set of fully observed MDPs that differ in their transitions. Every upper bound they prove on its shortfall assumes each MDP is communicating, with bounded diameter. Theorem 1 (§6) is kin to the construction of their Proposition 1, in which an irreversible choice is made before anything distinguishes the candidate MDPs, but that construction does not cover Theorem 1. That construction obtains a shortfall growing linearly in the horizon from per-step rewards in absorbing states, while Theorem 1's two-corridor toy has a single terminal reward and can reveal the corridor before the branch. Read as a latent MDP with the signals encoded as states, the toy has an absorbing failure, so their upper bounds do not apply either. Theorem 1 also measures a different gap: the adaptive optimum against the policy optimal for a fixed map. Chen et al. therefore do not subsume Theorem 1, and Theorem 1 does not extend their bounds. Pynadath & Tambe (2002) <d-cite key="pynadath2002"></d-cite> relate the complexity of team decision problems with communication to observability. Free communication lowers the complexity when the world is collectively observable (their Theorem 4 and Table 2), and makes no difference when it is individually observable or not observable at all (their Theorems 5–6). Remark 2′ (§7) refines this for collective partial observability: communication's marginal value vanishes when interchangeable agents' views are redundant, and returns when roles are irreplaceable or deaths are costly. A survey of adaptability in multi-agent reinforcement learning (Hu et al., 2025, revised 2026) <d-cite key="hu2025adaptablemarl"></d-cite> calls an environment family highly diagnostic if it "systematically varies" factors such as population, observability or communication structure "while holding other factors fixed". It mentions compositional generalization but does not analyse shifts in several factors at once.

We ran the literature search with the help of LLM-based research assistants, between August and October 2026. A census of benchmark venues and a search for theorems that could subsume ours came first; a search of domain randomization, environment design, multi-task and robust-learning neighbours followed. Both used web search and the arXiv API and read abstracts. The works this section describes in detail were then read in full; the remaining citations rest on their abstracts. We did not query IEEE Xplore. Wherever this paper says that no work does something, it means no work found by this search.


## 3 The environment


CHE is a grid world in which a team of agents forages while a fire burns; Figure 4 shows one step.

{% include figure.html path="assets/img/submission/fig01_schematic.png" class="img-fluid" alt="Five numbered boxes in a row, collapse, hazard, smoke, agents and comms, with a Coupling A arrow from collapse into the hazard box, a Coupling B arrow from smoke down to an observation box drawn from the post-step state, and comms denial entering the comms box with no hazard input." caption="Figure 4. One environment step of CHE." %}

<p class="caption">Collapse, fire, smoke, agents and communication are sampled in the order of Proposition 1. Coupling A (orange) carries c′ − c into the fire; Coupling B (blue) carries ρ′ into the observation, drawn from s′. The comms kernel takes δ and reads no hazard; T<sub>X</sub> reads the post-step h′ and c′, as in the code. Arrow colours are this figure's own. The reward is not drawn (Definition 2). <span class="figure-note">Status: schematic, no data.</span></p>

### 3.1 State, kernel and step order

**Definition 1 (Compound Hostile Environment).** A CHE is a Dec-POMDP $\mathcal{M}_\theta = \langle I, \mathcal{S}, \{\mathcal{A}_i\}, T_\theta, R, \{\Omega_i\}, O_\theta, \gamma \rangle$ with a finite set of agents $I$ on a grid $G$, action sets $\mathcal{A}_i$, observation sets $\Omega_i$, reward $R$ (Definition 2), observation kernel $O_\theta$ and discount $\gamma$. It is indexed by the *environment configuration* $\theta = (\beta, \kappa_A, \kappa_B, \delta)$: the fire's per-neighbour ignition probability $\beta$, the strengths $\kappa_A$ and $\kappa_B$ of Couplings A and B, and the communication-denial level $\delta$. Its state space factors as

$$
\mathcal{S} = \mathcal{X} \times \mathcal{H} \times \mathcal{P} \times \mathcal{C} \times \mathcal{K} \times \{0, \dots, T\},
$$

where $x \in \mathcal{X}$ holds the agents' positions $x_i \in G$, their alive flags $\alpha_i \in \{0, 1\}$ and the task state; $h \in \mathcal{H} = \{\mathrm{Fuel}, \mathrm{Burning}, \mathrm{Burnt}\}^G$ is the fire; $\rho \in \mathcal{P} = \mathbb{R}_{\ge 0}^G$ is the smoke field; $c \in \mathcal{C} = \{\mathrm{intact}, \mathrm{collapsed}\}^G$ is the structure; $k \in \mathcal{K}$ is the realized communication graph on $I$; and the last factor is the step index $t$, with horizon $T$. The transition kernel factorizes as

$$
\begin{aligned}
T_\theta(s' \mid s, a) = {} & \underbrace{T_C(c' \mid c, x)}_{\mathrm{collapse}} \; \underbrace{T_H^{\beta,\kappa_A}(h' \mid h, c, c')}_{\mathrm{fire;\ Coupling\ A}} \; \underbrace{T_\rho(\rho' \mid \rho, h')}_{\mathrm{smoke}} \\
& \times \underbrace{T_X(x' \mid x, a, h', c')}_{\mathrm{agents}} \; \underbrace{T_K^{\delta}(k' \mid x')}_{\mathrm{comms}},
\end{aligned}
$$

and agent $i$'s observation is drawn from the post-step state, $o'_i \sim O^i_{\kappa_B}(\cdot \mid x', h', \rho', c', k')$. The dependence of $T_H$ on the collapse increment $c' - c$ is Coupling A (§5); the dependence of $O^i_{\kappa_B}$ on the fire, through the smoke field $\rho'$ it produces, is Coupling B (§6). A training mixture (§9.1) draws $\theta$ once per episode, at reset. The slopes $\gamma_p$ and $\gamma_n$ (§9.2, Appendix H) are unrelated to this discount.

**Proposition 1 (Well-posedness and Markov closure).** For every $\theta$, the process $s_t = (x_t, h_t, \rho_t, c_t, k_t, t)$ under any joint policy is a Markov chain, and $\mathcal{M}_\theta$ is a well-defined Dec-POMDP: finite-horizon optimal joint policies exist, and the standard value definitions apply.

The proof (Appendix A) composes the five kernels in order. Because $\rho$ is real-valued the state space is not finite, but the states and observations reachable within the horizon form finite sets, and restricted to them $\mathcal{M}_\theta$ is a finite Dec-POMDP.

**Remark 1 (Hardness).** For two or more agents, the finite-horizon Dec-POMDP decision problem is NEXP-hard, and NEXP-complete when the horizon is below the number of states (Bernstein et al., 2002)<d-cite key="bernstein2002"></d-cite>. This bounds the worst case over the class and says nothing about a particular instance; it licenses the expectation that no general exact planner will scale, which is why we learn policies rather than plan.

Listing 1, the body of `step`, follows the factorization; the link graph is drawn on its own stream with no hazard argument, and the reward line reads only the task reward and the two death counts. In the listing, `tl` is the episode's $\theta$, and no configuration here uses the early `frozen` control branch. The observation is then drawn from the new state on its own stream (`che/env/env.py:394-396`).

**Listing 1.** One environment step in the order of Proposition 1.

```python
# che/env/env.py:298-358 (verbatim)
    k_struct, k_seed, k_fire = jax.random.split(key, 3)

    # 1. c' ~ T_C(c, x): reads *pre-step* occupancy.
    occ_pre = occupancy_grid(state.agent_pos, state.agent_alive, cfg.grid_size)
    structure_new = structure_step(
        k_struct,
        state.structure,
        state.weak,
        occ_pre.astype(jnp.float32),
        lambda_0=th.lambda_0,
        lambda_load=th.lambda_load,
    )
    collapse_increment = (structure_new == COLLAPSED) & (state.structure == INTACT)

    # 2. h' ~ T_H(h, c, c'): CA spread, then the Coupling A impulse from the
    # collapse increment (seeded cells are Burning in h', spread next step).
    seed_mask = coupling_a_seed_mask(
        k_seed, collapse_increment, kappa_A=tl.kappa_A, r_seed=th.r_seed
    )
    hazard_ca = hazard_step(k_fire, state.hazard, beta=tl.beta, iota=th.iota)
    if cfg.hazard_mode == "frozen":
        # M1.3: h is frozen — the CA/seed draws above still happen and are
        # discarded, so dynamic<->frozen with the same key share every
        # other stream bitwise (invariant #3). Frozen Burning cells stay
        # Burning: lethal and smoke-emitting, but never spread or burn out.
        hazard_new = state.hazard
        seeded_ignitions = jnp.zeros_like(seed_mask)
    else:
        hazard_new = seed_ignitions(hazard_ca, seed_mask)
        seeded_ignitions = hazard_ca != hazard_new  # Fuel cells Coupling A lit

    # 3. rho' from h' (Def. 6; smoke outlives flame).
    smoke_new = smoke_step(state.smoke, hazard_new, sigma_s=th.sigma_s, eta=th.eta)

    # 4. x' ~ T_X + task dynamics. M1.1: lethality/blocking against h'/c'.
    # DECISION: an agent disabled this step does not collect food this step
    # (it died before/on arrival) — occupancy filters on the post-death
    # alive vector, keeping "dead agents never collect" exact.
    pos_new, alive_new, deaths_fire, deaths_collapse, blocked_moves = agent_step(
        state.agent_pos,
        state.agent_alive,
        actions,
        hazard_new,
        structure_new,
        collapse_increment,
        cfg.grid_size,
    )
    occ_post = occupancy_grid(pos_new, alive_new, cfg.grid_size)
    food_new, task_reward = task_step(state.food, occ_post)
    # Def.-2-compliant death penalty: reads only the alpha transition (an X
    # variable) — never hazard/smoke/structure directly.
    reward = task_reward - th.death_penalty * (deaths_fire + deaths_collapse).astype(
        jnp.float32
    )

    # 5. k' ~ T_K(x'): comms channel (Def. 7, M5.0). Reads post-step
    # positions/aliveness only — never h', rho' or c' — and draws from its
    # own fold_in stream, so delta cannot perturb any kernel above.
    links, links_in_range = _comms_obs(
        jax.random.fold_in(key, _COMMS_STREAM), pos_new, alive_new, cfg, tl.delta
    )
```

### 3.2 The fire and its smoke

**Definition 3 (Fire kernel).** Each cell is Fuel, Burning or Burnt. At each step, independently for each ordered pair of a Burning cell $g$ and a Fuel von Neumann neighbour $g' \in N(g)$, the cell $g'$ ignites with probability $\beta$. A Burning cell becomes Burnt after exactly one step, and Burnt is absorbing. Fuel cells may also ignite spontaneously at rate $\iota \ge 0$ per step; CHE uses $\iota = 0$.

Every episode starts from an all-Fuel grid with one Burning cell at a uniformly random position (`che/env/env.py:241-243`). One uniform per cell and incoming direction realizes the per-edge Bernoulli variables of Proposition 2's coupling exactly (`che/env/hazard.py:8-16`; Appendix A), and cells outside the arena never burn.

**Proposition 2 (Bond percolation).** Under Definition 3 with $\iota = 0$ and a single ignition at the origin, the set of eventually-Burnt cells is equal in distribution to the open cluster of the origin in i.i.d. bond percolation on $(G, E)$ with edge-open probability $\beta$.

Here $E$ is the arena's set of von Neumann edges. The proof (Appendix A) is a short coupling, the correspondence between an epidemic with a constant infectious period and bond percolation described by Grassberger (1983)<d-cite key="grassberger1983"></d-cite>. Its hypotheses hold for CHE's fire when Coupling A is off, since collapses otherwise add ignitions.

Smoke outlives flame. Per cell,

$$
\rho' = e^{-\eta}\rho + \sigma_s \mathbf{1}[h' = \mathrm{Burning}],
$$

with emission $\sigma_s = 1.0$ and decay $\eta = 0.5$, held fixed by convention and never calibrated. A cell emits $\sigma_s$ once, in the step it burns, and its smoke then decays geometrically, with no spatial smoothing (`che/env/hazard.py:67-79`).

### 3.3 Agents, deaths and a hazard-blind reward

The agents kernel $T_X(x' \mid x, a, h', c')$ acts in three deterministic stages that consume no random numbers (`che/env/env.py:159-173`). An alive agent on a cell that collapses in this step is disabled before it moves. Survivors take one of 5 actions, stay or a von Neumann move clipped to the grid, and a move into a collapsed cell is cancelled. An agent whose new cell is Burning in $h'$ is then disabled, so a cell igniting under a standing agent kills it; Burning cells can be entered, and avoidance must be learned. A disabled agent stays disabled, holds still, collects nothing and disappears from the others' observations.

**Definition 2 (Ambient hazard).** The hazard is *ambient* if and only if (i) and (ii) hold.

(i) *Reward independence:* the reward is a function of task variables and of the agents' alive transition only,

$$
\begin{aligned}
R(s,a,s') = {} & R_{\mathrm{task}}(\mathrm{task}(x), a, \mathrm{task}(x')) \\
& - d_p\,\lvert\{i : \alpha_i = 1,\ \alpha'_i = 0\}\rvert ,
\end{aligned}
$$

where $\mathrm{task}(x)$ denotes the task variables (in CHE, the food grid and the alive agents' positions) and $d_p \ge 0$ is a fixed death penalty. No term of $R$ references $h$, $\rho$ or $c$, and the hazard appears in no auxiliary cost or constraint channel: no CMDP constraint, no Lagrangian penalty, no safety critic.

(ii) *Non-adversarial:* $T_H$ is a fixed stochastic kernel; nothing in the environment optimizes, learns or best-responds.

Under clause (i), survival is learned through two hazard-blind routes: a dead agent collects no further task reward, and each death costs a fixed $d_p = 0.5$, whatever its cause, in every configuration reported here except the $d_p$ ablation below (the code's default is 0). Fire and collapse reach return only through the transition and observation kernels. A hazard-priced reward signals the hazard's state whether or not anything is harmed: JaxWildfire, for example, penalizes its agent at every step in proportion to the number of burning cells (Çakır et al., 2025)<d-cite key="cakir2025jaxwildfire"></d-cite>. At $d_p = 0$ only the first route would remain.

Listing 2's signature admits only the food and occupancy grids: no fire, smoke or structure argument can reach the task reward.

**Listing 2.** The task reward reads food and occupancy only.

```python
# che/env/tasks.py:31-43 (verbatim)
def task_step(food: jax.Array, occupancy: jax.Array) -> tuple[jax.Array, jax.Array]:
    """Collection: an occupied food cell yields +1 team reward and empties.

    Multiple agents on one food cell still collect a single item (+1).
    Returns (food', team_reward). Reads task variables and agent occupancy
    only — no hazard/smoke/structure arguments, by design (Def. 2).
    """
    chex.assert_type(food, jnp.uint8)
    chex.assert_equal_shape([food, occupancy])
    collected = (food == 1) & occupancy
    reward = collected.sum().astype(jnp.float32)
    food_new = jnp.where(collected, jnp.uint8(0), food).astype(jnp.uint8)
    return food_new, reward
```

One test of clause (i) asserts identical rewards, with and without the death penalty, for states that differ only in fire, smoke or structure; fire and structure differ only far from every agent, which pins the alive transition equal (`che/tests/test_reward_independence.py:6-15`). It shows only that the reward reads no hazard state directly, since the fire is meant to change return through deaths. The other kills a standing agent by fire and, separately, by collapse, with identical task state, and asserts a reward of $-d_p$ both times (`che/tests/test_lethality.py:143-162`).

Clause (i) also fixes how §9's two co-primary outcomes enter learning: survival is a penalized channel, each death costing $d_p$, and completion a rewarded one, each collected item earning +1. §9.2 reads any asymmetry between them as one between a penalized channel and a rewarded one.

The one ablation of $d_p$ is from the calibration phase, with this scope: the fire alone with no coupling on, 500 updates, 3 seeds per cell, an observation encoding that predates the one used here, and means over the final training updates. Raising $d_p$ from 0 to 0.5 moved High survival from 0.575 to 0.866 and High completion from 0.765 to 0.821, moved Medium survival from 0.931 to 0.951 with completion 0.750 at both, and left Low tied, 0.991 against 0.992. It was not re-run under the current observation or with the couplings.

Clause (ii) does not make the hazard independent of the agents: a weak cell with an agent on it is nine times as likely to collapse in a step as an empty one, and a collapse can seed fire (§5.1).

### 3.4 Nested models: ablations are exact by construction

Each stressor is a parameter of one transition or observation kernel, and setting it to zero recovers a nested special case of the same model.

| stressor | parameter | lives in | off ($=0$) recovers | test (`che/tests/`) |
|---|---|---|---|---|
| Coupling A (§5) | $\kappa_A$ | $T_H$, through $c' - c$ | a fire blind to the structure | `test_nesting.py` |
| Coupling B (§6) | $\kappa_B$ | $O^i$ | the pre-masking observation, plus an all-ones visibility plane | Listing 3 |
| communication denial (§7) | $\delta$ | $T_K$ | free, range-limited communication | `test_comms.py` |

The fire's $\beta$ is a parameter of the same kind, positive in every configuration and set by severity (§4).

One engineering rule makes the nesting exact: every stochastic branch draws its uniforms unconditionally and compares them against a probability that may be zero. The draws for Coupling B's reveal, the links and the per-episode mixture use streams derived from the reset or step key by a fixed tag, so adding them left the existing streams untouched. Setting a stressor to zero therefore changes comparisons only, and the same keys reproduce the nested model's trajectory bit for bit.

Listing 3 runs the environment at $\kappa_B = 0$ with and without masking, under the same keys, and asserts bitwise-identical fire, smoke, structure, food, positions, alive flags and rewards. The rest of the test (`che/tests/test_coupling_b.py:143-156`) steps both by hand and asserts identical content planes, an all-ones visibility plane and a zero masked share.

**Listing 3.** With $\kappa_B = 0$, trajectories and rewards are bitwise those of the environment before masking.

```python
# che/tests/test_coupling_b.py:131-142 (verbatim)
def test_kappa_b_zero_bitwise_recovers_obs_v2():
    """Nesting (M4.1): obs v3 at kappa_B = 0 is the pre-masking env plus a
    constant all-ones visibility plane — state trajectories, rewards, and
    content planes bitwise identical to obs v2 under the same keys."""
    theta = dataclasses.replace(_HOT, kappa_B=0.0)
    cfg3 = EnvConfig(grid_size=L, n_agents=4, horizon=64, theta=theta)
    cfg2 = dataclasses.replace(cfg3, obs_version=2)
    a = _traj(theta, cfg=cfg3)
    b = _traj(theta, cfg=cfg2)
    _assert_bitwise_equal(
        a, b, ("hazard", "smoke", "structure", "food", "pos", "alive", "reward")
    )
```

With $\kappa_A = 0$, collapse activity leaves the fire and smoke bitwise unchanged (`che/tests/test_nesting.py:78-88`); at $\delta = 0$, the environment reproduces, on the CPU, a trajectory digest recorded before the communication channel existed (`che/tests/test_comms.py:272-319`). A structural test also asserts that the traced computation keeps its random-number primitives at parameter value zero, catching a gate such as `if kappa_A > 0:` that behavioural tests miss (`che/tests/test_nesting.py:222-240`).

### 3.5 The instance, training and metrics

Every trained policy and evaluation in this paper uses one instance: a 64 × 64 grid, 12 agents, a horizon of 256 steps, a 9 × 9 egocentric crop and 32 food items. Food sits on distinct cells from reset and does not respawn, and an alive agent on a food cell collects it for a team reward of +1. The observation's 8 channels are six indicators (burning, burnt, food, weak, collapsed, alive occupancy), the raw smoke density and Coupling B's visibility plane, which marks the revealed cells. An own-state vector gives the agent's row and column divided by the grid side, its alive flag and $t$ over the horizon.

All agents share one actor-critic network over the crop, the own-state vector and the aggregate of delivered messages. It has two convolutions with 16 and 32 channels, a dense layer of 128 units, and separate actor and critic heads with a 64-unit layer each. A message head receives no gradient; what it emits is a frozen-at-initialization projection of trained trunk features (§7).

Training is the independent PPO of de Witt et al. (2020)<d-cite key="dewitt2020ippo"></d-cite>, in the PureJaxRL style of Lu et al. (2022)<d-cite key="lu2022dpo"></d-cite>, on the environment conventions of JaxMARL (Rutherford et al., 2024)<d-cite key="rutherford2024jaxmarl"></d-cite>. Each seed trains one shared-parameter policy, whose update takes each agent's transitions as separate samples under the team reward. Each update collects 128 steps from 256 parallel environments, 32,768 environment steps, each advancing all 12 agents. ISO, ISO-4 and JOINT (§9) each train for T\* = 1000 updates, or 32,768,000 environment steps, with the hyperparameters of Appendix B.

The co-primary outcomes of §9 are per-episode. *Completion* is $1 - F/32$, where $F$ is the number of food items left at the episode's last step; *survival rate* is the fraction of the 12 agents alive at the end. Episodes always run to the horizon, even when every agent has died (`che/env/env.py:361`; `che/eval/harness.py:44-45`). Deaths are also recorded by cause, as diagnostics.


## 4 Severity calibration


Severity in CHE is placed by a measured dynamical phase of the fire: the three levels sit below, near and above the implemented kernel's measured transition (Figure 5).

<figure class="l-page">
  <iframe src="{{ 'assets/html/submission/severity_explorer.html' | relative_url }}" width="100%" height="528" style="border:none" title="Severity explorer: spanning probability against ignition probability, and one fire at each locked level" loading="lazy"></iframe>
  <figcaption><strong>Figure 5.</strong> Severity as a measured phase. Left: the spanning probability, the chance that one centre ignition reaches the arena boundary, against β on an all-fuel grid with no agents, for three arena sides (512 seeds per point). Vertical rules mark the locked levels; the triangle marks the largest arena's pseudo-critical point. Right: one random-policy episode per level under the severity configurations, with δ 0; only the fire and its smoke (hatching) are drawn. Neither the R<sub>L</sub> curves nor the locked critical point β̂<sub>c</sub> is shown (§4.3). <span class="figure-note">Status: calibration, no agents (curves) · illustrative, one episode each (renders) · Interact: play or drag the time slider; click a panel.</span></figcaption>
</figure>

<div class="print-companion">
{% include figure.html path="assets/img/submission/severity_explorer.png" class="img-fluid" alt="Spanning probability of a centre ignition against ignition probability for three grid sizes, with the three locked severities marked, beside one illustrative fire episode at each severity." caption="Static companion of Figure 5 for the printed PDF." %}
</div>

### 4.1 Phase structure of the idealized kernel

**Corollary 1 (Phase structure).** On $\mathbb{Z}^2$ with the von Neumann neighbourhood, the fire of Definition 3 with $\iota = 0$ and a single ignition at the origin inherits the phase structure of bond percolation (Proposition 2, whose coupling holds on any graph):

1. Its critical point is $\beta_c = 1/2$ exactly, the critical probability of bond percolation on the square lattice (Kesten, 1980)<d-cite key="kesten1980"></d-cite>.
2. For $\beta > \beta_c$ the fire spreads indefinitely with positive probability. On that event the cells ignited by step $n$ are those within $n$ open edges of the origin. Scaled by $1/n$, they converge almost surely in Hausdorff distance to a deterministic convex compact set with non-empty interior, invariant under permutations and reflections of the coordinates (Garet & Marchand, 2004; their Corollary 5.4)<d-cite key="garet2004chemical"></d-cite>. The growth is therefore linear in $n$, at a speed given in each direction by the extent of that set.

Both items concern the idealized kernel (von Neumann neighbourhood, constant burn time, homogeneous fuel, no wind) on the infinite lattice. CHE's fire is that kernel on a finite arena, with ignitions added by Coupling A (§5.1), so the levels are placed against a measured finite-size threshold and, at High, a measured front speed (§4.3).

### 4.2 Severity as phase

**Definition 4 (Severity regimes).** Fix the arena side $L$. Severity levels are defined by the position of the implemented kernel relative to its measured critical point $\hat\beta_c$, through the correlation length $\xi(\beta)$, the typical extent of a fire cluster:

- *Low*, subcritical, $\xi(\beta) \ll L$: fire clusters are local and short-lived, and survival is a local-avoidance problem.
- *Medium*, near-critical, $\xi(\beta) \sim L$: cluster sizes are scale-free up to the arena's size, fluctuations are maximal, and a single ignition can, with non-negligible probability, cascade to arena scale; survival is a global-anticipation problem.
- *High*, supercritical: fire fronts move at a speed comparable to the agents', and survival is a race.

The correlation length motivates the levels; operationally, each level is the observable band it was locked to, that is, fixed on 2026-07-19, before the main experiment (§4.3). As qualitatively different phases of one kernel, the levels make training at Low and High and evaluating at Medium (§9.1) a test of transfer to a phase neither arm trained in, though in the scalar $\beta$ it remains an interpolation (§10). Definition 4 also carried an expectation, on record before its test (§4.4), that per-episode outcome variance would peak at Medium.

### 4.3 Measuring the threshold and locking the levels

The calibration ran the fire alone on an all-Fuel grid at $L \in \{32, 48, 64\}$, with 512 seeds per $(L, \beta)$. A span sweep over 35 values of $\beta$ (0.05 to 0.95 coarsely, 0.40 to 0.60 in steps of 0.01), each from one centre ignition for $T_{\max} = 4L$ steps, measured $P_{\mathrm{span}}$, the burnt fraction and the front speed. A crossing sweep ignited the full left column and recorded the left–right crossing probability $R_L(\beta)$.

The severity lock fixed $\hat\beta_c = 0.500 \pm 0.005$, from logistic fits to $R_L$ with centres 0.4985, 0.5006 and 0.4999 at $L = 32, 48, 64$, and a self-duality check $R_L(0.500) = 0.488, 0.502, 0.494$. The lock record states that they were recomputed independently from the committed raw data; no committed script or artifact produces the logistic centres. Among the committed estimators, pairwise crossings of $R_L$ average 0.504; the family spans [0.480, 0.513], with consensus mean 0.499. Their range brackets Kesten's ½. That agreement validates the implementation; it is not a finding about fire, since Proposition 2 and Corollary 1 predict it for this kernel.

Each level was then locked to an observable band, with its measured values ($L = 64$, 512 seeds, no agents):

| level | $\beta$ | phase | $P_{\mathrm{span}}$ | burnt fraction | band the level was locked to |
|---|---|---|---|---|---|
| Low | 0.43 | subcritical | 0.021 | 1.9 % | $P_{\mathrm{span}} < 0.05$ and burnt fraction in [1, 5] % |
| Medium | 0.49 | near-critical | 0.547 | 19.8 % | $P_{\mathrm{span}}$ in [0.3, 0.7] |
| High | 0.70 | supercritical | 0.998 | 98.3 % | front speed in [0.5, 1.0] cells per step, measured 0.83 |

At High the front moves at 83 % of the agents' speed of one cell per step; escape is possible in principle. Medium sits between the finite-size pseudo-critical point $\beta_c(64) \approx 0.486$, where $P_{\mathrm{span}} = 1/2$ at $L = 64$, and $\hat\beta_c$. It is the severity of the held-out evaluation configuration of §9, $\theta^* = (\beta, \kappa_A, \kappa_B, \delta)$ = (0.49, 0.06, 1.0, 1.0); the compositional test trains at Low and High only.

### 4.4 Re-testing the Medium prediction

The calibration-phase probe at $d_p = 0.5$ (the fire alone, 500 updates, three seeds per severity) had saved no checkpoints. The re-test at fixed policy re-ran it from the same configurations and seeds (equivalent, not bitwise identical) and evaluated each final checkpoint on 512 episodes. For survival the prediction is refuted: per-episode variance at fixed policy is monotone in severity, 0.00091, 0.00709 and 0.00885 at Low, Medium and High. For completion it is not confirmed: Medium and Low tie within bootstrap intervals, 0.01245 against 0.01235, both above High. The environment-level mechanism is confirmed: with no agents, the burnt fraction's variance peaks near $\beta \approx 0.53$, just above Medium, and ranks Medium above High above Low at the locked levels.

The re-test report offers an account it did not test: outcome variance is roughly the environment's variance, which peaks near criticality, times the policy's sensitivity to it, which grows with severity. The refutation is scoped to survival, for these fire-only policies at this budget; §10 states what siting the held-out test at Medium costs.


## 5 Coupling A: collapse seeds the fire


Coupling A lets structural collapse feed the fire. Figure 1's event track marks one random-policy episode's collapses and the ignitions they seeded (press <kbd>]</kbd> in Figure 1 to step between them); Figure 6 counts them under trained policies.

<figure class="l-page">
  <iframe src="{{ 'assets/html/submission/coupling_a_explorer.html' | relative_url }}" width="100%" height="736" style="border:none" title="Coupling A explorer: collapse-seeded ignitions by severity, their share near agents, and the two Proposition 3 runs" loading="lazy"></iframe>
  <figcaption><strong>Figure 6.</strong> Coupling A under trained policies, and the Proposition 3 runs. <em>Top:</em> collapse-seeded ignitions per episode by severity, and their share inside an alive agent's crop, in the Coupling-B and Coupling-A calibration grids (labelled m44 and m35; Phases 3 and 4 are calibration stages). Whiskers are min–max over training seeds; neither grid has identical reruns, and nothing shown has a floor. <em>Bottom:</em> the two runs, kept apart, neither at the locked parameters; the second (v2, a revised test) has no committed data file, so its panel gives the reported values. <span class="figure-note">Status: top, trained policies, 500 updates, seed ranges; bottom, no agents · Interact: hover or tab to a point; table view.</span></figcaption>
</figure>

<div class="print-companion">
{% include figure.html path="assets/img/submission/coupling_a_explorer.png" class="img-fluid" alt="Collapse-seeded ignitions per episode at three severities for two trained grids, the share of them near agents, and the two Proposition 3 handshake runs shown separately." caption="Static companion of Figure 6 for the printed PDF." %}
</div>

### 5.1 Definition and implementation

**Definition 5 (Coupling A, as implemented).** Let $w(g) \in \{0,1\}$ mark weak terrain, a spatially clustered fraction $f_{\mathrm{weak}}$ of the cells drawn once per episode, and let $o_t(g) \in \{0,1\}$ indicate that at least one alive agent stands on cell $g$ before the step. An intact cell collapses at step $t$ with probability

$$
\lambda_t(g) = \big(\lambda_0 + \lambda_{\mathrm{load}}\,o_t(g)\big)\,w(g),
$$

so a cell that is not weak never collapses, and collapse is absorbing. Coupling A then ignites, with probability $\kappa_A$, each cell that is still Fuel after this step's spread and lies within Chebyshev distance $r_A$ of a cell that collapsed in this step. The fire kernel thus reads only the collapse increment $c' - c$, and a seeded cell is Burning in $h'$. Setting $\kappa_A = 0$ recovers the uncoupled fire kernel $T_H^{\beta,0}$, so the ablation "no Coupling A" is a nested model of the full system.

The theory states the impulse per collapse event; the implementation draws one uniform per cell, and the two rules coincide wherever seeding neighbourhoods do not overlap. The values, locked on 2026-07-21, are $(f_{\mathrm{weak}}, \lambda_0, \lambda_{\mathrm{load}}, \kappa_A, r_A) = (0.15,\ 5\times 10^{-5},\ 4\times 10^{-4},\ 0.06,\ 1)$, so the seeding neighbourhood is a 3 × 3 block.

Agents influence collapse, weakly and indirectly. Occupancy enters as a yes-or-no load: a weak cell with any agent on it collapses nine times as often as an empty one. Without load, the locked parameters give about 7.81 collapses per episode. Load adds 0.4 to 1.4 % to that count under trained policies (the Coupling-A calibration grid of §5.3) and 7.4 to 8.3 % under random ones, which is 6.9 to 7.6 % of all collapses. Agents cannot ignite a cell, but where they stand changes collapse rates, and a collapse can seed fire.

**Listing 4.** Coupling A's seeding mask, with its uniforms drawn whatever $\kappa_A$ is.

```python
# che/env/structure.py:83-102 (verbatim)
def coupling_a_seed_mask(
    key: jax.Array,
    collapse_increment: jax.Array,
    *,
    kappa_A: float,
    r_seed: int,
) -> jax.Array:
    """Coupling A (Def. 5): each cell in the seeding neighborhood N_A of a
    new collapse (Chebyshev radius r_seed) ignites independently w.p.
    kappa_A. `collapse_increment` is the boolean mask of c' - c, i.e. cells
    that collapsed *this step* — T_H reads the increment, not the stock.
    Returns the candidate ignition mask; `hazard.seed_ignitions` applies it
    to Fuel cells only.
    """
    chex.assert_rank(collapse_increment, 2)
    chex.assert_type(collapse_increment, jnp.bool_)
    # Invariant #3: uniforms drawn even when kappa_A == 0.
    u = jax.random.uniform(key, collapse_increment.shape)
    near_new_collapse = dilate(collapse_increment, r_seed)
    return near_new_collapse & (u < kappa_A)
```

The uniforms `u` are drawn before anything reads $\kappa_A$, so $\kappa_A = 0$ is the nested model bit for bit under the rule of §3.4. The mask then goes to `hazard.seed_ignitions`, which lights only cells still Fuel; this is where the fuel limitation of §5.3 enters.

### 5.2 The handshake with Proposition 3

**Proposition 3 (Collapse events dominate hazard exposure).** Work in the subcritical regime $\beta < \beta_c$ with $\iota = 0$, and suppose collapse events arrive at rate $\lambda_A$ per step, each seeding one ignition at a uniformly located Fuel cell, with seeded clusters pairwise disjoint (the sparse regime, $\lambda_A T \chi(\beta) \ll \lvert G \rvert$, the number of cells). Then the expected burnt area $B_T$ by time $T$ satisfies

$$
\begin{aligned}
\mathbb{E}[B_T] &= \lambda_A T\,\chi(\beta)\,\big(1 + o(1)\big), \\
\text{and in general} \quad \mathbb{E}[B_T] &\le \lambda_A T\,\chi(\beta),
\end{aligned}
$$

where $\chi(\beta)$ is the mean percolation cluster size. Consequently the marginal hazard exposure per unit of structural instability is $\partial\,\mathbb{E}[B_T]/\partial\lambda_A = T\chi(\beta)$.

The proof (Appendix A) grows each seed into a bond-percolation cluster by Proposition 2 and sums expectations; overlaps only remove double counting. With no primary ignition, as in both runs below, collapse is then the fire's only birth channel. In a finite protocol the equality is approached only with an unconditional cluster-mass reference (a spanning-conditioned one understates the mass), matched seed locations and ages, and sparse seeding; boundary clipping, seed age and overlapping seeds each lower the measured slope (Appendix A).

We tested the proposition in two runs, neither at the locked parameters, both without agents or primary ignition at the subcritical Low level ($\beta = 0.43$, $\iota = 0$). The first, a dense sweep on a 64 × 64 grid ($\kappa_A = 0.02$, $f_{\mathrm{weak}} = 0.4$), fits burnt area against realized seeds through the origin: $R^2 = 0.998$ over a 14× range of the expected seed count. The second, a slower test in the suite on a 32 × 32 grid ($\kappa_A = 0.003$), divides its slope by a protocol-matched reference computed inside the test: 0.992, inside the band [0.90, 1.02], with $R^2 = 0.9995$.

### 5.3 Under trained policies the coupling limits itself

In the Coupling-B calibration grid (500 updates at each severity, $\kappa_B$ off and on, Coupling A on), the $\kappa_B = 1.0$ arm records 4.05, 3.41 and 0.84 collapse-seeded ignitions per episode at Low, Medium and High, a 4.83-fold fall (from unrounded counts). The Coupling-A calibration grid ($\kappa_A$ off and on, with other policies, trained on the observation before masking) replicates it: 4.08, 3.42 and 0.83, a 4.92-fold fall.

Collapse never reads $\beta$; what changes with severity is where the seeds land. At High the fire burns 98.3 % of the arena in calibration, and the Fuel-only rule discards most seeding attempts. This concerns ignitions only: the Coupling-A grid's survival contrasts, on two seeds per arm and with no floor, cannot locate the coupling's largest effect on outcomes.

This fuel limitation was on record before any trained policy was measured. At the Coupling-A lock, the random-policy calibration put seeded ignitions at High about 5.7 times below Low at every $\kappa_A$ tried, and the lock recorded it as the fuel-exhaustion self-limitation of the ignition channel. A later prediction was written after the trained results existed and before its own analysis. It held that Coupling A is fuel-limited at High, that the co-active count of §6.5 need not be monotone in severity, and that Medium may be its peak. The 4.83-fold fall confirms the first, which earlier reports already answered. The count is monotone non-increasing and Low and Medium are indistinguishable, so the second is not supported and the third is refuted.

Across all nine measured cells (two arms of the Coupling-B grid and one of the Coupling-A grid, at three severities), the share of seeded ignitions inside an alive agent's crop stays in [0.164, 0.203].

At Low the coupling moves survival in the Coupling-A grid off its ceiling, from 0.979 to 0.961, as fire deaths per episode rise from 0.062 to 0.229. Weak-cell occupancy is higher by 0.054 with the coupling on, which suggests, on two seeds per arm, that the policies do not learn to avoid weak cells. No contrast in this section has a floor on its own artifact, since neither grid has identical reruns; any floor beside them is a reference scale (cross-artifact); see §8.6.


## 6 Coupling B: smoke attenuates perception


Coupling B makes what an agent perceives depend on the hazard's own state. Figure 1 opens on agent 7 at t = 128 and shows that agent's observation as produced, the true state of the same 9 × 9 cells, and the probability that each cell was seen.

### 6.1 Definition and implementation

**Definition 6 (Coupling B: Beer–Lambert observation, as implemented).** Smoke is the per-cell state field $\rho'$ of §3.2, updated after the fire with no spatial smoothing, so it outlives flame. For agent $i$ at $x_i$ and a cell $y$ of its crop, let $\bar\rho_i(y)$ be the mean of $\rho'$ at the four points $x_i + t_s(y - x_i)$, $t_s = (s + \tfrac12)/4$ for $s = 0, \dots, 3$, each read at the nearest cell (smoke outside the grid reads 0). The transmittance is

$$
\tau_i(y) = \exp\!\big(-\kappa_B\,\lVert y - x_i \rVert_2\,\bar\rho_i(y)\big),
$$

a midpoint-rule form of $\exp(-\kappa_B \int_{x_i \to y} \rho\,d\ell)$ along the line of sight. Each crop cell is revealed independently with probability $\tau_i(y)$: a revealed cell passes its seven content planes, an unrevealed one passes zeros, and an eighth plane records the realized reveal, so the agent can tell "unseen" from "empty". The own cell has distance 0 and is always seen. Setting $\kappa_B = 0$ gives $\tau \equiv 1$ and recovers hazard-independent observation.

Because $\rho'$ is hazard state, perception degrades where and when the fire is active.

**Listing 5.** Coupling B in the observation kernel: transmittance, the reveal draw and the visibility plane.

```python
# che/env/observation.py:300-310 (verbatim)
        tau = transmittance(
            state.smoke, state.agent_pos, kappa_B=state.theta_live.kappa_B, k=k
        )
        reveal = jax.random.uniform(key, tau.shape) < tau  # P(seen) = tau
        grid = jnp.concatenate(
            [
                grid * reveal[..., None].astype(jnp.float32),
                reveal[..., None].astype(jnp.float32),
            ],
            axis=-1,
        )
```

The `reveal` line draws its uniforms whatever $\kappa_B$ is, so at $\kappa_B = 0$ the mask is all ones and the environment is bitwise the one before masking (§3.4, Listing 3). The draw has its own random stream, and $\kappa_B$ is read per episode from the state, which is how a training mixture varies it.

### 6.2 What attenuation does to the value of adaptivity

**Theorem 1 (Memorization gap, and its erosion by Coupling B).** Consider the two-corridor environment $E_{2C}(\kappa_B)$: from a start cell, a path of $d$ steps leads to a branch $b$, from which two disjoint corridors $L$ and $R$ of length $\ell$ lead to the goal; the horizon is $T = d + \ell$ (zero slack: a wrong commitment cannot be undone). At $t = 0$ nature draws $Z \in \{L, R\}$ uniformly; corridor $Z$ burns at depth $\ell_f \ge 1$ beyond $b$, and an agent entering it is disabled. The reward is 1 for reaching the goal by $T$, else 0. At each step $t \le d$ the agent receives the signal $Y_t = Z$ with probability $e^{-\kappa_B (d - t + \ell_f)}$ (Beer–Lambert over the current distance to the fire, unit smoke density), else $Y_t = \varnothing$; signals are independent across time and remembered. Let

$$
q(\kappa_B) = 1 - \prod_{j=\ell_f}^{d+\ell_f} \big(1 - e^{-\kappa_B j}\big)
$$

be the probability of being informed by the commitment point. Then (1) the optimal value is $J^*(\kappa_B) = \tfrac12 + \tfrac12 q(\kappa_B)$; (2) the policies optimal for the fixed-map variant ($Z \equiv z_0$ constant) include the signal-blind policy "always take the corridor other than $z_0$", whose value on $E_{2C}$ is $\tfrac12$ for every $\kappa_B$, so the memorization gap is $J^*(\kappa_B) - J^{\mathrm{static}} = \tfrac12 q(\kappa_B) > 0$ for all finite $\kappa_B$; and (3) $q$ is continuous and strictly decreasing in $\kappa_B$, with $q(0^+) \to 1$ and $q(\kappa_B) \to 0$ as $\kappa_B \to \infty$, so under total perceptual denial the optimal adaptive policy is no better than the memorizing one.

In one toy (proof in Appendix A), a memorizing policy loses exactly half the probability of being informed, and the hazard's own attenuation shrinks that loss continuously to zero; the theorem says nothing about what a learner does in CHE.

The theorem also tests the code. The toy and the observation kernel share one transmittance function, and the toy's information probability agrees at every grid point across Monte Carlo, the closed-form product and the full observation pipeline. The measured optimal value matches $\tfrac12 + \tfrac12 q$ under a three-condition gate: largest $\lvert z \rvert$ 2.11, $\sum z^2 = 6.55$ on 8 degrees of freedom ($p = 0.586$), and mean $z$ −0.44. The memorizing policy stays flat at ½, $J^*(0) = 1.0000$, and $J^* - \tfrac12 = 0.0000$ at $\kappa_B = 8$, where $q = 0.0056$.

### 6.3 The lock: three bands that did not intersect

The strength $\kappa_B$ was to be locked where three bands set before calibration intersect. They were a masked share of the crop at Medium in [0.15, 0.45], a probability in [0.4, 0.7] that a Burning cell three cells away is revealed at Medium, and a toy information probability $q$ in [0.3, 0.7]. They do not intersect. The masked-share band cannot be reached at Medium: the masked share can only approach the share of crop cells with smoke on their line of sight, 0.130 there under a random policy, below the band's lower edge of 0.150. The same $\kappa_B$ attenuates the arena's extended smoke more strongly than the toy's single smoke source, which leaves the detection and toy bands disjoint by a factor of 1.35 under a random policy and 1.15 under probe policies. On 2026-07-27, $\kappa_B = 1.0$ was locked on the detection band alone; the masked-share band was retired, not widened, and the toy band kept as a consistency check.

### 6.4 Survival cost at High severity

{% include figure.html path="assets/img/submission/fig04_coupling_b.png" class="img-fluid" alt="Left, the masked share of the agent crop at three severities, over all alive agent-steps and at danger moments, on a log scale. Right, three replicate survival contrasts at high severity and then the first estimate, against a hatched band one standard deviation wide on a reference scale measured on another artifact." caption="Figure 7. Coupling B: where the masking falls, and the High survival contrasts." %}

<p class="caption">(a) Masked share of the crop in the coupled arm of the Coupling-B calibration grid (labelled m44 and M4.4), over all alive agent-steps and at danger moments. (b) The High survival contrasts between the arms: three replicates, then the first estimate. The hatched band, labelled floor, is a reference scale (cross-artifact). The figure cannot show intervals, completion or Medium. <span class="figure-note">Status: trained policies, 500 updates · static.</span></p>

At High, three replicate contrasts of survival between $\kappa_B = 1.0$ and $\kappa_B = 0$ are negative three times out of three (Figure 7(b); trained policies, 500 updates, $d_p = 0.5$, Coupling A on). They are −6.87 and −10.66 points for the grid's two seeds and −4.70 points for a same-seed retrain, each one run per cell and without an interval. The grid's first estimate, the mean of its two seeds, was −8.8 points. The High survival floor, sd 6.21 points, was measured later on four identical runs of a separate artifact: a reference scale (cross-artifact). The first estimate is 1.41 times this floor and the replicates' mean about 1.19 times it. We report a consistent effect of modest size; the first analysis graded it "strong" against a two-seed spread, a label retracted under the rule of §8.1. Completion is not resolved, since its contrast flipped sign on the same-seed retrain.

At Medium, the severity of the held-out test configuration (β = 0.49), Coupling B's own survival effect in the same grid was −0.03 points. It was judged against a three-seed spread, $\sigma_{\mathrm{seed}} = 0.72$ points, with no measured floor; the Medium survival floors measured later, on two GPUs, are 1.29 and 1.30 points. Coupling B's measured survival cost is therefore at High, while §9's test runs at Medium (§10, item 1).

The masking concentrates on moments of danger, alive agent-steps with a Burning cell inside the agent's crop. In the $\kappa_B = 1.0$ arm the masked share of the crop at danger moments is 0.0809, 0.0560 and 0.2424 at Low, Medium and High, against 0.00068, 0.00249 and 0.01559 over all alive agent-steps: 118, 22 and 16 times more concentrated (ratios of unrounded shares; Figure 7(a)). Within trained policies at 500 updates the attenuation was not behaviourally suppressed: the coupled policies' masking ceiling, which does not depend on $\kappa_B$, sat at or above its random-policy value at every severity.

### 6.5 The co-active counter, and what it can see

The environment logs, at every step, the number of collapse-seeded ignitions inside an alive agent's crop, within Chebyshev radius 4 of its post-step position. It was meant to catch both couplings at once, but only Coupling A produces those ignitions and $\kappa_B$ does not enter the count, so the counter is co-active only in all-on configurations. In a training mixture it reads the Coupling-A marginal alone, which is why the mediation analysis registered on it is void (§9.2).

{% include figure.html path="assets/img/submission/fig05_coactive.png" class="img-fluid" alt="Three bar charts, one per severity, of the share of episodes with zero, one, two, three, and four or more co-active events." caption="Figure 8. The co-active counter per episode, by severity." %}

<p class="caption">Share of episodes with each number of co-active events in the coupled arm of the Coupling-B calibration grid (labelled m44), seeds pooled; both couplings are on in every cell. The figure cannot show a floor, since none exists for this counter, or a training mixture (§6.5). <span class="figure-note">Status: descriptive; trained policies, 500 updates; no floor · static.</span></p>

In these all-on cells the counter is rare and bursty (Figure 8). The share of episodes with no co-active event is 0.563, 0.578 and 0.883 at Low, Medium and High, the mean at Medium is 0.64 events per episode, and the variance-to-mean ratio, 1.31 to 1.40, exceeds the Poisson value of 1. Low and Medium are indistinguishable and High is lower, because seeded ignitions fall while the near-agent share stays in its range (§5.3).


## 7 Communication denial: inert under this encoder at this scale


The third stressor denies links between agents. In CHE, under a frozen encoder, no measured effect of it cleared a valid bar (Figure 9; one threshold is VOID, §7.3).

{% include figure.html path="assets/img/submission/fig06_comms.png" class="img-fluid" alt="Top left, courier success rate against perception attenuation in the two-agent toy, for free and for denied communication, with the predicted curve. Top right, the denial contrasts at medium severity with their bars. Bottom, the per-run values behind those contrasts." caption="Figure 9. Communication in the toy, and denial in CHE at Medium." %}

<p class="caption">(a) The courier variant of the corridor toy (labelled E2C² and M5.2), scripted policies: success with free and with denied communication on the no-idle schedule (pinned); the shaded gap is VoC<sub>gated</sub> (§7.2). (b–d) The denial study (M5.5): contrasts against bars (post-hoc floor grading), and the runs. No panel grades inertness or shows the content ablations, High severity, the VOID condition or a trained encoder. <span class="figure-note">Status: descriptive · static.</span></p>

### 7.1 The kernel

**Definition 7 (Communication denial, as implemented).** After the agents move, the comms kernel $T_K(k' \mid x')$ samples a directed link graph over the alive agents: for every ordered pair $i \ne j$ of alive agents,

$$
\Pr\big[\, i \to j \text{ open} \,\big] = \mathbf{1}\big[\lVert x'_i - x'_j \rVert_\infty \le R_{\mathrm{comm}}\big]\,(1 - \delta),
$$

with $R_{\mathrm{comm}} = 16$ cells. Each agent emits a message $m_i \in [-1, 1]^{8}$ at step $t$; at $t + 1$ each receiver $j$ gets the mean of the messages delivered over the links then realized, $\bar m_j = \sum_i k'_{ij}\, m_i \,/\, \max(1, \sum_i k'_{ij})$, which is the zero vector when $j$ is isolated. $T_K$ reads positions and aliveness only, so denial is mechanistically independent of the fire. One uniform per ordered pair is drawn at every step whatever $\delta$ is, so $\delta = 0$ gives the deterministic range graph and $\delta = 1$, the value locked on 2026-07-30, gives the empty graph, both bitwise. The theory's range-dependent link probability is implemented as this hard Chebyshev range.

**Listing 6.** Delivered messages carry no gradient.

```python
# che/train/ippo.py:323-329 (verbatim)
        # Messages emitted this step are delivered next step. Nothing crosses
        # an episode boundary (autoreset), and stop_gradient states in code
        # what the batch-storage already implies: the channel is not a
        # differentiable path (Q3 ruling; networks.py docstring).
        messages = jax.lax.stop_gradient(
            jnp.where(done[:, None, None], 0.0, emitted)
        )
```

No gradient crosses the channel, so the message head, a tanh-bounded dense layer on the trunk, stays at its initialization: an agent emits a frozen random projection of trunk features that are themselves trained. The receivers' weights on the message inputs are trained, which makes message use testable; what to say was never learned.

### 7.2 When communication should matter

Remark 2′ refines a result of Pynadath & Tambe <d-cite key="pynadath2002"></d-cite>. Free communication lowers the complexity of the team decision problem when the world is collectively observable (their Theorem 4 and Table 2), and makes no difference when it is individually observable or not observable at all (their Theorems 5–6). Remark 2′ concerns the value of communication under collective partial observability.

**Remark 2′.** Extend $E_{2C}$ with a second agent. (i) Under a team-any reward, communication has zero marginal value when the agents are interchangeable, expendable (no death cost) and at least as numerous as the hypotheses: coverage then achieves $J = 1$ under total denial. When any qualifier fails, value returns; in general it scales with the deficit of agents relative to hypotheses, and a death cost, such as CHE's $d_p = 0.5$, prices the redundancy that substitution spends. (ii) In the courier variant, where only agent 1 can complete the task and it observes the other agent only through messages, the denied optimum within the no-idle policy class is $\tfrac12 + \tfrac12 q(\kappa_B)$; with slack $\ell_f$, optimal denied play buys information by idling at the branch and achieves $\tfrac12 + \tfrac12 \tilde q(\kappa_B)$, where $\tilde q$ is the probability of being informed by the commitment point under the best idling schedule, with $\tilde q \ge q$ (equality iff $\ell_f = 0$), so

$$
\mathrm{VoC}_{\mathrm{true}}(\kappa_B) = \tfrac12\big(1 - \tilde q(\kappa_B)\big) \le \tfrac12\big(1 - q(\kappa_B)\big).
$$

Both $q$ and $\tilde q$ decrease in $\kappa_B$, so the value of communication increases with perception decay.

We ran the courier variant with scripted policies, delivering messages through the production link kernel and computing $\tau$ with the shared transmittance function, which tests both kernels. The free arm always succeeds, the no-idle denied arm matches $\tfrac12 + \tfrac12 q$, and the value of communication against that arm, $\mathrm{VoC}_{\mathrm{gated}} = \tfrac12(1 - q)$, rises monotonically from 0 to 0.498 (Figure 9(a); Appendix A).

### 7.3 In CHE the channel carries nothing measurable

CHE's agents meet one of Remark 2′(i)'s qualifiers: they are twelve interchangeable agents sharing one set of parameters. Nothing establishes that they are at least as numerous as the hypotheses, and their deaths are priced ($d_p = 0.5$), so the clean-zero conditions are not fully met.

In a content ablation at Medium ($\delta = 0$, $R_{\mathrm{comm}} = 8$, two seeds, 500 updates), three arms of identical architecture pass live, zeroed or shuffled messages (the delivered aggregate set to zero with links kept; sender identities permuted within a step). No pair differs beyond a bar of twice the earlier Medium floor, about 3 points. The same ablation at High (three seeds, $R_{\mathrm{comm}}$ = 8 and 16) found that raising the mean alive out-degree from 1.01 to 2.99 changed nothing, ruling out "nobody was in range". The wider High floors put its bars at 10.44 (completion) and 12.43 points (survival).

In the denial study (Medium, four seeds, $R_{\mathrm{comm}} = 16$, message path live in both arms), completion is 0.38 points higher and survival 1.43 points lower with links open ($\delta = 0$) than with links denied ($\delta = 1$), against bars of 7.99 and 2.60 points. Both bars are twice the floor sd measured on the GPU that ran the study (Figure 9(b–d)). Every bar here is a post-hoc floor grading that a true effect of its size would clear only about half the time (§8.2), so none of these results is a point null. A further condition, on danger-moment outcomes, is VOID: its threshold, chosen at implementation, sat below the quantity's own run-to-run nondeterminism (§8.1).

The content ablations supply a mechanism: in the live arm a receiver can tell that it heard from someone without decoding anything; in the zeroed arm it cannot. That signal needs no encoder and went unused at both severities and, at High, at both ranges. The neglect is therefore on the demand side (the agents did not need the information) rather than the channel side (they could not read it), and the frozen encoder cannot account for it.

Because deaths are priced, Remark 2′(i) leaves communication some value here, which the measurements find weak at this scale and this death price. Gradient-shaped messaging is untested, and a bound measured on a frozen random encoder does not strictly bound a trained one. We claim only that communication denial is inert under a frozen random-projection encoder at this scale.

The composition §9 tests is, in effect, Coupling A × Coupling B, with $\delta = 1.0$ kept in $\theta^*$ for fidelity to the registration. The δ-only third of ISO's training is fire-only, and §9.1 gives the consequence.


## 8 Methodology: bars come with floors


GPU training is not reproducible run to run: the compiler chooses kernels by timing them and some reductions use atomics. A reproducibility floor is the standard deviation of a metric over identical reruns, with the same seed, configuration and code. Each rule below came from a defect in the project's record; Appendix C lists every floor.

<figure class="l-page">
  <iframe src="{{ 'assets/html/submission/floors_explorer.html' | relative_url }}" width="100%" height="472" style="border:none" title="Floors explorer: reproducibility floors per GPU, per artifact and per run length, and the confirmatory grid against its floor" loading="lazy"></iframe>
  <figcaption><strong>Figure 10.</strong> Reproducibility floors per GPU, per artifact and per run length, and the confirmatory grid against its floor, one tab each, with its confound. On the figure, "card" is the GPU, "box" the machine, "tree" a code version and "reps" identical reruns; M5.1e, M5.5 and M6.0 are keyed in Appendix C. "Traced" and "baseline" are the refactored and reference versions, compared by per-field trajectory hashes ("field digests"); "floor-basis sd(Γ)" is the floor-based standard error of Γ (§8.4). It cannot show contrasts without a floor (§8.6). <span class="figure-note">Status: point estimates over identical reruns, about ±40 % uncertain at four reruns · Interact: click a tab or press ← / →; hover or tab to a mark.</span></figcaption>
</figure>

<div class="print-companion">
{% include figure.html path="assets/img/submission/floors_explorer.png" class="img-fluid" alt="Reproducibility floors on two GPUs, rerun comparisons of two versions of the code, floor growth from the shorter to the longer run length, and the confirmatory grid's seed dispersion against its floor, each with its confound stated." caption="Static companion of Figure 10 for the printed PDF." %}
</div>

### 8.1 A bar without a floor is void

No acceptance threshold enters an analysis script without a measured floor for the quantity it grades, or an explicit UNDERPOWERED flag. A threshold below its instrument's noise cannot pass under the null, so its output is void, and a void test voids a PASS as it voids a FAIL. The rule followed four bars with invented constants (Appendix C). In one, the denial study of §7 graded a condition with a 20 % threshold, chosen at implementation, against a quantity whose rerun nondeterminism is 27.2 %. Since the threshold sits below the noise, the condition is VOID; the observed 23.2 % exceeded the threshold but not the noise.

Floors are facts per metric and per GPU. Re-measuring the Medium floor moved completion's 2.75-fold and left survival's unchanged, 0.0129 against 0.0130. The two studies differ in GPU, code version and configuration, so the exhibit cannot say which of the three moved the completion floor. The floor is measured on the GPU that runs the grid.

Floors are facts per artifact. In a refactor of the environment code, the rerun floor measured on the reference version read zero, so two diagnostic channels that differed between the versions looked like a semantic change. The refactored version then differed from itself 1 time in 4 on the same channels. An equivalence claim between A and B needs A against A and B against B as well as A against B.

### 8.2 Contrasts and power

A contrast is graded on its own standard error. For Γ, the difference between the JOINT and ISO arm means over $k_{\mathrm{JOINT}}$ and $k_{\mathrm{ISO}}$ seeds with seed standard deviations $s_{\mathrm{JOINT}}$ and $s_{\mathrm{ISO}}$,

$$
\operatorname{sd}(\Gamma) = \sqrt{\frac{s_{\mathrm{ISO}}^2}{k_{\mathrm{ISO}}} + \frac{s_{\mathrm{JOINT}}^2}{k_{\mathrm{JOINT}}}},
$$

which for equal $k$ is $\sqrt{(s_{\mathrm{ISO}}^2 + s_{\mathrm{JOINT}}^2)/k}$. The per-arm forms, each arm's own $s\sqrt{2/k}$, bracket that value without equalling it: at $k = 34$, on the 1000-update completion floors and a 0.03 effect, ISO's gave 92.1 % power and JOINT's 62.8 %, where the contrast's power was 76.7 %.

A design-stage power statement is the minimum detectable effect at 80 % power and the family-corrected level,

$$
\mathrm{MDE}_{80} = \big(z_\alpha + z_{0.8}\big)\,\operatorname{sd}(\Gamma),
$$

with $z_\alpha = 2.2365$ the Šidák-corrected critical value for the two co-primaries. The exclusion bound $X$ that §9 attaches to a null is this quantity on the grid's realized seed dispersion. A bare $2\sigma\sqrt{2/k}$ is the effect at which an uncorrected test would just reject, which it detects about half the time; it survives only for grading an observed effect against a floor after the fact, labelled as such. The confirmatory seed count was first ruled at $k = 20$ on such a figure, without the Šidák correction; corrected, completion had 55.6 % power against its motivating effect band, a slip caught before any run.

### 8.3 Floors move with the run, and gates must not divide by them

Floors grow with run length. From 500 to 1000 updates the completion floor grew 2.1-fold for ISO and 5.2-fold for JOINT, with length confounded with machine.

A gate that divides by a floor diverges on more reproducible hardware. A registered convergence check, retired before the grid, divided each arm's late-training drift by its floor, so any nonzero drift fails as the floor goes to zero; it fired when JOINT's floor fell faster than its drift. The $T^*$ ruling of 2026-08-11 retired it as a gate, fixed the estimand as Γ at matched compute, and made Γ(t) required robustness evidence (§9.2).

### 8.4 The floor is a check, not the test variance

The floor and the test statistic are different variances. A floor comes from identical reruns at one seed, while a $k$-seed arm mean varies by seed as well. The confirmatory contrast is graded on the grid's own seed dispersion. The floor serves the check that an effect exceeds rerun noise, which uses the floor-based standard error of Γ: the display in §8.2 with floors in place of seed standard deviations (§9.2). For design-stage power, the floor gives an upper bound, labelled as one.

### 8.5 Instruments state what they are blind to

A differenced test sees asymmetry and nothing else. A condition of the form "no cross-arm difference in X" cancels any X present in both arms. In 24 of 24 rendered episodes of the Coupling-B calibration grid, the alive agents' centroid drifted towards a wall (rendered-pixel centroids, a diagnostic). That grid's inertness falsifier, logged before its data, included the condition "no cross-arm exposure/positioning difference", which could not see a drift present in both arms; the verdict it fed rests on its other conditions.

Measuring is not grading. A recorded channel becomes evidence only inside a registered analysis family, with a floor measured on its artifact. Position-drift diagnostics added before the grid are recorded for every grid run. They are recorded, not graded: adding them to the registered family after registration would have enlarged it and inflated its correction.

The differential drift between the arms, bias (b) of §9.1, changed sign between the four floor studies that read it at 1000 updates before unblinding, so §9.1 reports every reading.

### 8.6 Where this paper falls short of its own rules

Coupling B's Medium survival effect was judged only against a three-seed spread (§6.4). The trained-policy contrasts of §5 and §6 come from two calibration grids without identical reruns: their spreads are seed ranges, and any floor shown beside them is a reference scale (cross-artifact). In the secondary design, floors exist only for the sweep arm at $p = 0.5$; the intermediate sweep arms assume that floor, and the identification arm is ungraded. ISO-4 has no identical reruns, so the contrasts that involve it are graded on seed dispersion alone, and the High-severity readout flags ISO-4 UNDERPOWERED for the check against rerun noise. The position-drift diagnostics have no floor. Every floor is itself a point estimate: measured on four identical runs, a standard deviation is uncertain by roughly ±40 %.


## 9 The pre-registered compositional test


### 9.1 Design

**Definition 8 (Training protocols and the compositional gap).** Let $J_\theta(\pi)$ be the expected episodic return of joint policy $\pi$ in $\mathcal{M}_\theta$, and let $\theta^*$ be the test configuration, every stressor on at a severity held out of training. Let $\Theta_{\mathrm{iso}}$ be the configurations in which at most one of $\kappa_A$, $\kappa_B$, $\delta$ is nonzero; the fire ($\beta > 0$) burns in all of them. The ISO protocol trains one policy $\pi_{\mathrm{iso}}$ on a uniform mixture of configurations in $\Theta_{\mathrm{iso}}$. The JOINT protocol trains one policy $\pi_{\mathrm{joint}}$ on a mixture whose support includes configurations with every stressor on, at training severities only. The compositional gap is

$$
\Gamma(\theta^*) = J_{\theta^*}(\pi_{\mathrm{joint}}) - J_{\theta^*}(\pi_{\mathrm{iso}}).
$$

The registered test replaces $J$ by an outcome metric's mean over evaluation episodes, on two co-primaries: task completion, the founding primary, and survival rate (§3.5). Survival became a co-primary on 2026-08-02, before the grid, because, as that ruling records, both couplings' calibration grids had moved survival while their completion effects sat at or below the floors then measured (§5–§6).

**Proposition 4 (A transfer bound for a fixed policy).** For a fixed policy and two configurations that share the reward, the difference between its discounted returns is bounded above by a term that grows with how far their transition and observation kernels differ. Every configuration in $\Theta_{\mathrm{iso}}$ differs from $\theta^*$ on the states where both couplings act at once, a collapse-seeded fire within perception-attenuation range of an agent (proof idea in Appendix A).

Proposition 4 bounds what ISO can be *guaranteed* to transfer, not what happens. It does not lower-bound Γ, and compositional generalization can emerge from isolated training; it motivates the experiment, and the experiment decides. Its prediction about ISO's exposure to that region was not tested, because the counter built to measure visits there (§6.5) is co-active only in all-on configurations (§9.2).

The test configuration θ\* has every stressor on at the held-out severity, β 0.49, $\kappa_A$ 0.06, $\kappa_B$ 1.0, δ 1.0, and no arm trains at β 0.49 (Figure 2 in §1). In the table, μ is the per-coupling frequency, the share of training episodes carrying a given coupling, and p the co-occurrence, the share carrying both. The active share is the share with at least one behaviourally active stressor, and the fire-only share ν, counted behaviourally, is the rest.

| arm | components, each at β 0.43 and 0.70 | μ | p | active share | fire-only ν |
|---|---|---|---|---|---|
| ISO | A-only, B-only, δ-only; 6 × 1/6 | 1/3 | 0 | 2/3 | 1/3 |
| ISO-4 | A-only, B-only; 4 × 1/4 | 1/2 | 0 | 1 | 0 |
| JOINT | all-on; 2 × 1/2 | 1 | 1 | 1 | 0 |

ISO-4, a sensitivity arm outside the confirmatory family, is ISO without its two δ-only components, and the corrected gap Γ₄ is JOINT − ISO-4. All arms share the network and the IPPO hyperparameters (Appendix B), one shared-parameter policy per training seed<d-cite key="dewitt2020ippo"></d-cite>, a budget of T\* = 1000 updates of 32,768 environment steps each, and one evaluation draw, seed 0 × 512 episodes at θ\*.

Γ is read at matched compute, at the fixed budget T\*, and convergence is claimed nowhere. The confirmatory family is the two co-primary tests, Šidák-corrected (m = 2): unpaired normal z tests against $z_\alpha = 2.2365$ on the contrast's standard error from each arm's seed dispersion (§8.2). A null carries its exclusion bound X, the 80 %-power MDE at that α. Positive cross-arm covariance, the expected sign given the shared seed integers, makes the unpaired test conservative. Floors serve only the check that an effect exceeds rerun noise (§8.4) and, as an upper bound, design-stage power (Appendix D); every interval is conditional on the one evaluation draw.

The design registered k = 40 seeds per arm and a seed rule, capped at 60, that recomputes k from floors re-measured on the grid's GPU. It gave 46 on an RTX PRO 6000 and 72 on GPU 1, the RTX 5090 that ran the rest of the grid and every run in the confirmatory artifact (GPU 2 and GPU 3 are two more of that model; Appendix F). Raising the cap to 72 on 2026-09-22 was a deviation from a registered rule, recorded as one, made before unblinding, and conservative, since added seeds favour neither sign of Γ. The registered k = 60 analysis, on seeds 1–60, is reported beside it; realized completion power at a 0.03 effect is 60.2 % and 71.6 % at k = 60 and 72.

JOINT sees each coupling three times as often as ISO, so Γ mixes per-coupling frequency with composition. A secondary sweep holds μ = 0.5 while p moves from 0 to 0.5, in the spirit of DBCA<d-cite key="keysers2020"></d-cite>, which the ISO and JOINT endpoints do not follow. On the triangle of training mixtures $\mu = (1 + p - \nu)/2$, so a fixed μ forces ν = p. Identification arms on the parallel line μ = 0.4, ν = 0.2 + p identify a plane in p and ν (Appendix H). Secondary arms run k = 20 seeds, with δ off, on GPU 1. The p = 0 sweep arm therefore trains on ISO-4's mixture on JOINT's GPU, and JOINT, unlike every secondary arm, carries δ = 1.0, inert (§7). The secondary design is **non-verdict-bearing**.

The registered design contains an error, and the bias it creates inflates Γ. Communication denial had been found inert on 2026-07-30 (§7). The design registered on 2026-08-02 kept δ in θ\* for fidelity to the registration and excluded it from the secondary sweeps because it was inert. It still gave ISO two δ-only components of six. A question it set for reviewers judged the arms symmetric on δ, on the premise that neither trains on δ = 1.0, which is false for both, and asked for a second opinion. So a third of ISO's training episodes are fire-only, which the design never counted: ISO's configured no-stressor share of 0 is true nominally and false behaviourally, and JOINT's active share is 1.5 times ISO's. A review of the registered design identified this on 2026-08-16, before the grid, noting that the confirmatory arm applied a different rule to the same fact as the sweeps. The grid began on 2026-09-09 without the correction. The bias, its direction and ISO-4 with its reading rule were registered on 2026-09-18, mid-grid (120 of 252 runs) and before unblinding, on our attestation, recorded with the ruling, that no outcome mean had been computed or viewed. The composition actually tested is A × B.

Bias (b) is the registered caveat on differential drift: JOINT − ISO completion drift over the last 100 of 1000 training updates, a local sensitivity estimate and never a bound. The four floor studies that read it at 1000 updates gave +0.0242 per 100 updates on the confirmatory arms' floor study, +0.01209 on the grid's launch floor study (2026-08-10) and +0.0179 on the 2026-09-08 re-measured floor, all three on an RTX PRO 6000, but −0.0083 on GPU 1. In the 2000-update subsample (T = 2000 in the registration; §9.2), the differential training-log slopes over updates 500–1000 are +0.00247 (completion) and +0.00718 (survival) per 100 updates. The sign reverses on the grid GPU, and no direction is claimed.

The registered outcomes, branches A–D of 2026-08-13 and a fifth cell, $A_c$, added before unblinding, are in Appendix E. Beyond a null completion contrast and a positive survival contrast, branch B needs a registered falsifier to pass. The ISO-4 rule states that if Γ rejects on a co-primary and "**Γ₄'s CI on that co-primary includes 0 or its sign is opposite**, the paper states that the effect **does not survive the inert-share correction**". If Γ and Γ₄ are both null, "Γ₄ is quoted as a second exclusion bound". Appendix D quotes every rule with its date.

The grid ended on 2026-09-22; its runner computes no cross-arm quantity. On 2026-09-26 the pre-unblind rulings fixed the statistic, the sign rule, k = 72 as primary and $A_c$. Unblinding, the first computation of any outcome contrast, followed the same day (Appendix F).

### 9.2 Results

<figure class="l-page">
  <iframe src="{{ 'assets/html/submission/ladder_registered_readings.html' | relative_url }}" width="100%" height="1012" style="border:none" title="Registered readings in order: Gamma, Gamma4, Gamma4 prime and B-hat on both co-primaries" loading="lazy"></iframe>
  <figcaption><strong>Figure 11.</strong> The registered readings in order, one row (a “rung”) per contrast: Γ, with the registered k = 60 analysis (labelled “prefix”); Γ₄; Γ₄′, JOINT minus the p = 0 sweep arm (labelled sweep_c50_p000); and B̂, which carries no verdict. “Unit n” is GPU n, “cross-unit” means across GPUs, and the “seed ladder” is the registered seed rule (§9.1). The grey band is the 80 %-power MDE; the stipple, on Γ only, is ±1 floor-based standard error of Γ (labelled “floor basis”). The figure cannot show effects present in both arms, evaluation-set sampling, other budgets, or which of active share and per-coupling frequency carries the ISO-4 − ISO difference. <span class="figure-note">Status: registered (Γ); sensitivity arm (Γ₄); secondary (Γ₄′) · Interact: step rows with ◀ ▶ or the arrow keys; toggle the bands; “table view”.</span></figcaption>
</figure>

<div class="print-companion">
{% include figure.html path="assets/img/submission/ladder_registered_readings.png" class="img-fluid" alt="Two forest plots, completion and survival, of the registered contrasts in order with their Šidák-corrected intervals and verdicts" caption="Static companion of Figure 11 for the printed PDF." %}
</div>

At k = 72, Γ rejects on survival and is null on completion (Figure 11 and the contrast table). The completion null excludes a joint-training gain larger than 0.66 points, the upper end of its interval. Its exclusion bound X, the gap of either sign the design would detect with 80 % power, is 3.29 points, and the negative point estimate does not reject. The registered k = 60 analysis reads the same and is flagged UNDERPOWERED.

All contrasts at θ\* and T\* = 1000 unless the row says otherwise, in points (rate × 100), with Šidák-corrected 95 % intervals unless marked; k is given in the order of the contrast's two arms.

| contrast | k | completion | survival | status |
|---|---|---|---|---|
| Γ = JOINT − ISO | 72 / 72 | null: −1.73 [−4.12, +0.66], z −1.62 | REJECT: +0.96 [+0.47, +1.44], z +4.43 | confirmatory |
| Γ, registered k = 60 analysis | 60 / 60 | null: −2.17 [−4.86, +0.52], z −1.80 | REJECT: +1.04 [+0.54, +1.55], z +4.67 | seeds 1–60, UNDERPOWERED |
| Γ₄ = JOINT − ISO-4 | 72 / 20 | null: −1.26 [−4.81, +2.28], z −0.80; second exclusion bound | null: −0.03 [−0.68, +0.63], z −0.09 | sensitivity arm, across GPUs |
| Γ₄′ = JOINT − the p = 0 sweep arm | 72 / 20 | null: −2.47 [−6.16, +1.22], z −1.50 | null: +0.13 [−0.56, +0.81], z +0.41 | secondary, same GPU, read at $z_\alpha$ |
| B̂ = ISO-4 − ISO | 20 / 72 | −0.46 [−4.05, +3.12] | +0.98 [+0.33, +1.63] | no registered test, no verdict; across GPUs |
| replicate difference: p = 0 sweep arm − ISO-4 | 20 / 20 | +1.21 [−2.79, +5.20], 95 % | −0.15 [−0.86, +0.56], 95 % | secondary, across GPUs |
| $\Gamma_H$, all-on at β = 0.70 | 72 / 72 | null: −0.79 [−3.26, +1.68] | null: +0.38 [−1.46, +2.23] | evaluation only, out of family, not held out |
| $\Gamma_{H,4}$ = JOINT − ISO-4 at β = 0.70 | 72 / 20 | null: −0.75 [−3.87, +2.36] | null: −1.28 [−3.50, +0.95] | no reading rule of its own |
| Γ(2000) | 4 / 4 | +0.03 [−3.63, +3.69], 95 % | +1.59 [−0.02, +3.19], 95 % | descriptive, UNDERPOWERED |

The registered falsifier passes. It requires the completion contrast to exclude, in standardized units, an effect as large as the observed survival effect. With $z_c$ and $z_s$ the two statistics Γ / sd(Γ), $\lvert z_c\rvert + z_\alpha = 3.855 < 4.433 = \lvert z_s\rvert$ (4.040 < 4.673 at k = 60). Branch B stands, completion null and survival positive, and branch C does not apply. Under Definition 2 the asymmetry is between a penalized channel and a rewarded one: the reward prices every death at $d_p = 0.5$ whatever its cause and never reads the hazard. Branch A, the founding hypothesis, did not occur, and neither did $A_c$.

Γ₄ is null on survival. By the registered rule, Γ rejects and Γ₄'s interval contains 0, so the survival effect **does not survive the inert-share correction**, and this paper does not call it a composition effect. The branch label stays B, because the rule fixes it by Γ. Branch B's registered headline, "composition is paid in agents, not task return", no longer holds as worded. On completion both contrasts are null, so Γ₄ is a **second exclusion bound**, X₄ = 0.0488 (4.88 points).

Γ₄ is a contrast across GPUs: ISO-4 trained on GPU 2, JOINT on GPU 1. Γ₄′, the same-GPU replicate of the correction, is JOINT minus the p = 0 sweep arm (§9.1). It was proposed on 2026-09-26, after Γ₄ was seen and before that arm was read, and by rule it cannot change Γ₄'s qualifier. It agrees: null on both co-primaries.

B̂, ISO-4 − ISO, has no registered test and no verdict, and no magnitude threshold on it was registered. Because Γ = Γ₄ + B̂ holds identically for arm means, a B̂ close to Γ restates a Γ₄ close to 0 and is not a second finding.

Γ₄'s upper bound, +0.63 points, lies above Γ's lower bound, +0.47, so the correction excludes a large composition effect but leaves a smaller one possible. Removing the δ-only episodes also raises both the active share, from two thirds to one, and each coupling's frequency, from a third to a half, and B̂ alone cannot say which matters. What Γ₄ does say is that, once the active share is matched, JOINT's remaining differences add nothing detectable to survival, although JOINT still sees each coupling twice as often as ISO-4 and always in combination.

Γ(t) is **sign unstable over the final half** on both co-primaries (Figure 12; Appendix G gives every value): the registered rule calls the result budget-robust only if all 11 point estimates over updates 500–1000 share one sign. As registered, the instability is the finding, and every reading here holds at matched compute only. Survival Γ(t) stays between −0.37 and +0.36 points through update 850, every interval containing zero. It reads +0.56, +0.83 and +0.96 points at updates 900, 950 and 1000, the only checkpoints whose Šidák interval excludes zero: the survival gap opens only in the last fifth of the budget. Completion is negative at every checkpoint from update 700, 70 % of the budget, and its interval excludes zero only at update 750, −1.47 points [−2.83, −0.10], descriptively. Completion is unresolved and leans negative.

<figure class="l-page">
  <iframe src="{{ 'assets/html/submission/gamma_t_final_half.html' | relative_url }}" width="100%" height="503" style="border:none" title="Gamma over the final half of training, completion and survival" loading="lazy"></iframe>
  <figcaption><strong>Figure 12.</strong> <strong>Sign unstable over the final half</strong>, on both co-primaries. Γ(t) is JOINT − ISO over the final half of training, with Šidák whiskers. A ringed sign differs from the sign at T&#42;; rule (iv) is the pre-unblind sign ruling quoted in Appendix D. Only the checkpoint at T&#42; is the registered Γ; earlier intervals are descriptive. “Grid card” is GPU 1 and “post-unblind card” GPU 3; the “single-card curve” re-evaluates the T&#42; checkpoints on GPU 3. The dotted box is ±1 floor-based standard error of Γ (labelled “floor basis”). The figure cannot show where either difference goes after T&#42;. <span class="figure-note">Status: registered at T&#42;, descriptive before · Interact: hover a checkpoint; toggle the single-card curve and the box.</span></figcaption>
</figure>

<div class="print-companion">
{% include figure.html path="assets/img/submission/gamma_t_final_half.png" class="img-fluid" alt="The retained checkpoints over the final half of training of the joint-minus-isolated difference in completion and in survival, each with its Šidák interval, labelled sign unstable over the final half" caption="Static companion of Figure 12 for the printed PDF." %}
</div>

The 2000-update subsample (4 seeds per arm, UNDERPOWERED) keeps a positive differential training-log slope over updates 1000–2000, +0.00204 (survival) and +0.00384 (completion) per 100 updates, as over 500–1000 (§9.1). The drift it measures has not visibly reversed, which is all it may be cited for.

The secondary design (Figure 13; Appendix H) reports 95 % intervals that are not family-corrected. At ISO's fire-only share of 1/3, the survival plane's fire-only-share slope γ<sub>n</sub> predicts ISO-4 − ISO = +0.79 points, inside B̂'s interval. This does not attribute B̂ to the fire-only share as such, because at fixed p a move in ν also moves μ. The co-occurrence slope γ<sub>p</sub> is positive across the sampled region, but moving single-stressor into both-stressor episodes also raises each coupling's frequency, and the triangle does not separate the two. Fitted on p up to 0.5, the plane predicts JOINT − ISO-4 = +3.26 points at p = 1, far above the measured Γ₄ and Γ₄′: γ<sub>p</sub> does not extrapolate to JOINT.

<figure class="l-page">
  <iframe src="{{ 'assets/html/submission/simplex_secondary.html' | relative_url }}" width="100%" height="832" style="border:none" title="Secondary design on the triangle of training mixtures, with plane predictions beside measured contrasts" loading="lazy"></iframe>
  <figcaption><strong>Figure 13.</strong> The secondary design; the change point is labelled “knee”. Left: the triangle of training mixtures in co-occurrence p and fire-only share ν (labelled n), lines of fixed per-coupling frequency μ (labelled m), and the arms. Right: the secondary estimates, where γ<sub>p</sub> and γ<sub>n</sub> are the co-occurrence and fire-only-share slopes, the “dose slope” is the sweep's slope in p, and the “no-element share” is the fire-only share's part of the sweep's endpoint change. Below, the plane's γ<sub>n</sub> prediction sits beside B̂, which it fits, and its γ<sub>p</sub> prediction beside Γ₄ and Γ₄′, which it misses; the p = 0 sweep arm is labelled sweep_c50_p000. The figure cannot separate per-coupling frequency, co-occurrence and active share. <span class="figure-note">Status: secondary · Interact: switch the metric; toggle the predictions; hover.</span></figcaption>
</figure>

<div class="print-companion">
{% include figure.html path="assets/img/submission/simplex_secondary.png" class="img-fluid" alt="A triangle of training mixtures by share of both-stressor and fire-only episodes, locating the secondary arms, ISO, ISO-4 and JOINT, beside the secondary estimates and the plane predictions next to the measured contrasts" caption="Static companion of Figure 13 for the printed PDF." %}
</div>

On a secondary metric outside the family, descriptive and without a floor, JOINT has 0.1177 fewer fire deaths per episode than ISO (z = −4.59); expressed in agents, the survival gap is about 0.11 of the 12 agents per episode.

The High-severity readout re-evaluated every T\* checkpoint of ISO, JOINT and ISO-4 with every stressor on at β = 0.70, out of family. Both co-primaries are null, so the reading is an **a-fortiori exclusion**: no gap larger than 3.40 completion points or 2.54 survival points at High even where JOINT trained on the evaluated configuration and ISO never saw a composed one. $\Gamma_H$ lies within rerun noise, at 0.73 and 0.75 times its floor-based standard error (completion, survival); ISO-4 has no identical reruns, so that check is UNDERPOWERED for it. The readout is not a held-out test: JOINT trained on this configuration at weight 1/2. At High, Coupling B's survival effect replicated in direction in 3 of 3 contrasts (§6.4) while Coupling A is marginal (§5.3), the mirror image of θ\*'s Medium siting (§10).

Mediation is **VOID**. The registered mediator, the counter's realized count during training, had a first-stage slope on p of −1.03 × 10⁻⁵, 95 % [−2.91 × 10⁻⁵, +0.93 × 10⁻⁵]. A rule fixed before the sweep was read voids it when that interval contains zero. Diagnosed after the run, with the rule unchanged: the counter counts collapse-seeded ignitions inside an alive agent's crop, which only Coupling A produces. In mixtures it measures the Coupling-A frequency that the sweep holds fixed and is blind to co-occurrence.

Seed dispersion exceeds the rerun floor in both arms, 1.12 and 1.09 times on completion and 1.25 and 1.19 times on survival (ISO, JOINT). Survival Γ, at 5.40 times its floor-based standard error (completion 1.78 times), clears the check that an effect exceeds rerun noise. Γ and Γ₄′ ran on GPU 1 and the post-unblind evaluations on GPU 3 (Appendix F); §11 reports how closely evaluation reproduces on one GPU and across GPUs.

### 9.3 A recommendation and its scope

A comparison of joint and isolated training that leaves the active share free can report an active-share effect as a composition effect. This follows from the comparison's design alone, as JOINT's threefold per-coupling frequency over ISO does. We make one recommendation, motivated by this result alone: that studies of compositional generalization match the share of training that contains an active stressor before attributing a gain to composition. It was motivated in one environment at one scale, and whether it holds elsewhere is untested. Matching the active share here left JOINT's other differences in place, and the corrected contrast excludes only a large composition effect (§9.2).


## 10 Limitations


Items 1 to 10 are properties of the design, stated whatever the outcome. Each was listed, in this order, before unblinding, and item 1 was registered as applying to every outcome.

1. θ\* sits at Medium, where Coupling B's own measured survival effect was −0.03 points, graded only against a three-seed spread. Coupling B's survival effect is at High, where the Coupling-B contrast replicated in direction three times out of three, between −4.7 and −10.7 points; the registered text quotes the first two-seed estimate, 8.8 points. Medium was chosen because both couplings clear their lock criteria there and its floors are the smallest, which trades the existence of a behavioural effect for measurability. By the project's own locks, no severity has both couplings strongly live: at Medium B is quiet and A live, and at High A is marginal by construction (§5.3) and B live. The High readout adds breadth in severity and does not test composition where both couplings bite. The pre-unblind line that read a Medium survival effect as one "the single coupling did not show" is struck: Γ₄ and Γ₄′ contradict it.
2. θ\* is one held-out point, interpolated in one scalar between the training severities β = 0.43 and 0.70, and no training data lies near criticality.
3. The task requires no coordination: twelve agents share one policy's parameters and a team reward of +1 per collected item; "swarm" is not a claim.
4. The reward sees deaths, at $d_p = 0.5$ each, and not the hazard, so the asymmetry between survival and completion is between a penalized channel and a rewarded one. The only $d_p$ ablation is narrow and was not re-run under the protocol of §9 (§3.3).
5. Communication denial is inert under a frozen random-projection encoder at this scale: the message head receives no gradient, and gradient-shaped messaging remains untested. The composition the test probes is A × B; δ is carried in θ\* for registration fidelity.
6. The observation includes the agent's own position and the time step, so a policy can condition on where and when it is, independently of the hazard. The wall-drift artifact (§8.5) is the visible form, and no differenced test can see it; the position-drift diagnostics are recorded, not graded.
7. Every interval in §9 is conditional on one common evaluation draw, seed 0 × 512 episodes, which cancels in Γ; the intervals carry training-seed variance only.
8. The confirmatory runs and every analysed secondary run, the same-GPU replicate's included, trained on GPU 1; ISO-4 trained on GPU 2, so Γ₄ and B̂ are across GPUs; and the post-unblind evaluations ran on GPU 3 (Appendix F).
9. No external baseline, domain-randomization schedule or adaptive curriculum is evaluated; every arm uses one learner, single-policy IPPO, with one hyperparameter set (Appendix B).
10. The hazard is simple: a one-step burn time, a single ignition at reset, no spontaneous ignition ($\iota = 0$), and no wind or fuel heterogeneity. Corollary 1's exact critical value is specific to this idealized kernel on the infinite lattice.

Registered or recorded before unblinding:

- The confirmatory comparison carries a design error, which inflates Γ: a third of ISO's training episodes are fire-only (§9.1). Its correction, registered before unblinding, rests on a 20-seed sensitivity arm outside the confirmatory family, trained on another GPU.
- Several bars have no floor on their own artifact, because the design ran no identical reruns for them (§8.6).
- The confirmatory seed count exceeds the registered seed rule's cap, a deviation recorded before unblinding (§9.1).
- Proposition 4 (A transfer bound for a fixed policy) bounds what isolated training can be guaranteed to transfer and does not lower-bound the realized gap; the experiment decides (§9.1).

Found after unblinding:

- The survival effect does not survive the inert-share correction; the branch label stays B (§9.2). The correction excludes only a large composition effect and leaves open whether the active share or the per-coupling frequency carries the ISO-4 − ISO difference, which is reported without a test. The same-GPU replicate, proposed after Γ₄ was seen, agrees.
- On both co-primaries Γ(t) is sign unstable over the final half, so Γ is a claim at matched compute only; the 2000-update subsample, UNDERPOWERED by registration, cannot settle another budget (§9.2).
- Completion is unresolved: its null is an exclusion with its bound, and it leans negative late in training (§9.2).
- The registered mediator was blind to co-occurrence in mixed training, so mediation is VOID (§9.2).
- The secondary analyses report many intervals, none family-corrected (Appendix H).

All of it was measured in one environment, at one scale, with one learner: the scope of the recommendation in §9.3.


## 11 Reproducibility


The code behind this paper is one repository. It holds the environment, training, evaluation and calibration code, and every configuration, θ\* and the generated protocol configurations included. It also holds the analysis scripts that produced the results of §9, a registry of the locked constants, and a CPU test suite that runs the theory checks as unit tests. A test asserts that the configurations and code defaults agree with the registry and that each registered analysis constant equals the literal in the script that uses it. Each listing is a verbatim excerpt of the repository, labelled with file and lines.

Ablations are exact by construction: every stochastic branch consumes its random numbers whether or not its stressor is on, so switching a stressor off reproduces the nested model's trajectories bit for bit under the same keys (§3.4, Listing 3). Four repeated evaluations of each of two checkpoints are bit-identical on one GPU and identical to the grid's own evaluations. Re-evaluated on another GPU, the final checkpoints of all confirmatory runs gave identical completion and survival values in 280 of 288 checkpoint–metric pairs, and the largest absolute difference is 2.44 × 10⁻⁴. GPU training is not run-to-run reproducible (§8), which is why floors are measured (Appendix C).

On GPU 1, an RTX 5090, a 1000-update training run took 518–521 s and a 512-episode evaluation 9–10 s (Python 3.12.3, jax 0.11.0). A run is 32,768,000 environment steps, each advancing all 12 agents; Appendix B gives the hyperparameters. These are training measurements. The paper states no environment-only throughput figure, because under the compiler's dead-code elimination such a figure depends on which outputs its consumer reads.

The §9 checkpoints were archived off the rented machines with recorded sha256 hashes, except a partial floor set that grades nothing, in which one of 12 archives has a hash (Appendix F). A re-verification matched every recorded hash. The analysis scripts refuse to run out of order, and each stage's log records a single run (Appendix F).


## Appendices


- Appendix A: proofs.
- Appendix B: locks and hyperparameters.
- Appendix C: reproducibility floors.
- Appendix D: the frozen analysis plan, quoted.
- Appendix E: the registered outcome branches.
- Appendix F: grid provenance and blinding.
- Appendix G: Γ over the final half of training.
- Appendix H: the secondary design.
- Appendix I: trained-policy episodes.

### A Proofs

Each statement is in the body, in the section named. The proofs follow the formal specification in the notation of Definition 1, and departures from it are noted.

**Proposition 1.** Statement in §3.1.

**Proof.** Each factor of $T_\theta$ is a conditional kernel, measurable in its conditioning variables, all of which are components of $(s, a)$ or of already-sampled components of $s'$. The dependence of $T_H$ on $c'$ and of $T_K$ on $x'$ is a sequential composition within one time step. Sample $c' \sim T_C(\cdot \mid c, x)$, then $h' \sim T_H(\cdot \mid h, c, c')$, then $\rho' = T_\rho(\rho, h')$ (deterministic), then $x' \sim T_X(\cdot \mid x, a, h', c')$, then $k' \sim T_K(\cdot \mid x')$. A composition of Markov kernels is a Markov kernel on the product space, so $T_\theta$ is a valid transition kernel on $\mathcal{S}$ and $(s_t)$ is Markov. The action sets are finite, every stochastic factor and the reset distribution have finite support, and $\rho$ evolves deterministically from $\rho_0 = 0$. The states and observations reachable within the horizon therefore form finite sets; restricted to them, $\mathcal{M}_\theta$ is a finite Dec-POMDP, and optimal finite-horizon joint policies exist by the standard argument. $\blacksquare$

The formal specification states that $\mathcal{S}$ and $\Omega_i$ are finite. With the real-valued smoke field $\rho \in \mathbb{R}_{\ge 0}^G$ in the state, that holds only for the states and observations reachable within the horizon, which is all the argument uses.

**Proposition 2.** Statement in §3.2.

**Proof (coupling).** Attach to each unordered edge $e = \{g, g'\}$ an independent $B_e \sim \mathrm{Bernoulli}(\beta)$, and declare that a transmission attempt across $e$ succeeds if and only if $B_e = 1$. Each edge is attempted at most once: when one cell of $e$ first Burns while the other is Fuel, one attempt occurs; afterwards the burning endpoint is Burnt, which is absorbing. If the other endpoint later Burns via a different path, its neighbour across $e$ is already Burnt, so no second attempt occurs. Run with the variables $\{B_e\}$, the fire therefore burns exactly the connected component of the origin in the subgraph of open edges $\{e : B_e = 1\}$, which is the bond-percolation cluster. $\blacksquare$

This is the coupling behind the correspondence that §3.2 cites<d-cite key="grassberger1983"></d-cite>, and the implementation realizes it exactly (`che/env/hazard.py:8-16`). It draws one uniform per cell and incoming direction, which maps one-to-one to the ordered pairs of Definition 3. With a burn time of one step, each unordered edge sees at most one attempt, so these uniforms are the coupling's per-edge variables.

**Proposition 3.** Statement in §5.2.

**Proof.** Each collapse seed grows, by Proposition 2, a burnt cluster equal in distribution to a bond-percolation cluster, of expected size $\chi(\beta)$. By linearity of expectation over the Binomial or Poisson number of seeds, the total expected burnt area is $\lambda_A T \chi(\beta)$ when clusters are disjoint; overlaps only remove double counting, which gives the upper bound in general. $\blacksquare$

The formal specification adds a divergence rate near the critical point, which rests on critical exponents the paper does not state (§4.1). The equality is approached only when four conditions are matched, each with a known sign. They are an unconditional cluster-mass reference (a spanning-conditioned one underestimates it), seed location (boundary clipping lowers the mass of uniformly placed seeds), seed age (seeds born late have not reached full mass, which lowers the measured slope; at β = 0.43 mass saturates by an age of about 64 steps), and sparsity (sibling seeds and cluster overlap deflate the measured slope). In the Proposition 3 measurements (§5.2) the four factors compose to the observed slope within Monte Carlo error.

**Theorem 1.** Statement in §6.2; items (1)–(3) below refer to it.

**Proof.** *(1)* With zero slack, the only decision is the corridor choice at $b$; waiting or probing is impossible within $T$. If informed (probability $q$), taking the corridor other than $Z$ succeeds with probability 1; if not, both corridors are exchangeable given the history, and any choice succeeds with probability $\tfrac12$. Hence $J^* = q + (1-q)\tfrac12 = \tfrac12 + \tfrac{q}{2}$, and no policy exceeds this, since success requires information or a lucky guess. *(2)* In the fixed-map environment the signal is uninformative, so the signal-blind policy is among the optimal ones there; on $E_{2C}$ it succeeds if and only if $Z = z_0$, with probability $\tfrac12$. *(3)* Each factor $(1 - e^{-\kappa_B j})$ is continuous and strictly increasing in $\kappa_B$ on $(0, \infty)$, so the finite product is too, and $q$ is continuous and strictly decreasing. The product tends to 0 as $\kappa_B \to 0$ and to 1 as $\kappa_B \to \infty$. $\blacksquare$

**Proposition 4 (A transfer bound for a fixed policy).** Statement in §9.1.

**Proof idea.** The difference between the two returns is bounded by telescoping the evaluation operators of the two models along the trajectory distribution; the observation term enters because the policy acts through the observation. Every configuration in $\Theta_{\mathrm{iso}}$ differs from $\theta^*$ where both couplings act at once. Take a state with a collapse increment next to Fuel and an agent within attenuation range. There $T_{\theta^*}$ places mass of order $\kappa_A$ on ignition transitions that a configuration with $\kappa_A = 0$ places elsewhere, and the observation kernels differ when $\kappa_B$ differs.

The formal specification displays the bound with an explicit constant and concludes more about ISO's slack than an upper bound can show; the paper states the bound in words and draws no such conclusion (§9.1).

**Remark 2′.** Stated in §7.2, after Pynadath and Tambe<d-cite key="pynadath2002"></d-cite>. One step is not spelled out in §7. Let $\tilde q$ be the probability of being informed under the best idling schedule. The commitment draws have different optical depths, so as $\kappa_B \to \infty$ the lowest-depth draw dominates both products and $\tilde q / q \to 1$. The correction peaks at moderate $\kappa_B$, and its relative bite on the value of communication is largest at low $\kappa_B$, where $q$ is near 1. In the two-agent toy, which is not CHE (4096 episodes and 8192 Monte Carlo draws per point), $\tilde q / q$ is 1.126 at $\kappa_B = 1.0$ and peaks at 1.235 near $\kappa_B = 2$. The correction removes 79 %, 54 % and 7 % of $\mathrm{VoC}_{\mathrm{gated}}$ at $\kappa_B$ = 0.5, 1.0 and 3.0. The check that the denied arm under the no-idle schedule matches $\tfrac12 + \tfrac12 q$ passes (largest absolute z 0.44; χ² 0.51 on 8 degrees of freedom), and the arm with free communication scores 1.0000 at every $\kappa_B$.


### B Locks and hyperparameters


Each locked constant below was fixed by a ruling on the date given, and the test described in §11 checks each against the configurations, the code defaults or the analysis scripts.

| constant | value | ruled | record |
|---|---|---|---|
| critical point $\hat\beta_c$ | 0.500 ± 0.005 | 2026-07-19 | severity lock record; no committed script reproduces its estimator, and the committed estimators give a crossing mean of 0.504 and a consensus of 0.499 |
| β Low / Medium / High | 0.43 / 0.49 / 0.70 | 2026-07-19 | severity lock record |
| β held out (θ\*) | 0.49 | 2026-08-02 | the ruling that sited θ\*: train at the two extremes and hold out the middle |
| $f_{\mathrm{weak}}$, $\lambda_0$, $\lambda_{\mathrm{load}}$, $\kappa_A$, $r_A$ | 0.15, 5e-5, 4e-4, 0.06, 1 | 2026-07-21 | Coupling-A lock record |
| weak-floor smoothing passes | 2 | 2026-07-21 | Coupling-A lock record, locked as the code default |
| $\kappa_B$ | 1.0 | 2026-07-27 | Coupling-B lock record, on the detection band alone |
| δ off / on; $R_{\mathrm{comm}}$ | 0.0 / 1.0; 16 | 2026-07-30 | communication lock record |
| death penalty $d_p$ | 0.5 | 2026-07-19 | the death-penalty design decision |
| observation encoding | 3, the masking observation (§3) | 2026-07-24 | the observation design decision |
| $\sigma_s$, η, ι | 1.0, 0.5, 0.0 | not locked | held fixed by convention, never calibrated |

| analysis constant | value | ruled | role |
|---|---|---|---|
| `K_CONFIRMATORY` | 40 | 2026-08-03 | design seeds per confirmatory arm, the seed rule's base |
| `K_LADDER_CAP` | 60 | 2026-08-03 | the seed rule's cap |
| `K_CONFIRMATORY_REALIZED` | 72 | 2026-09-22 | the seed count at which Γ is read, a recorded deviation (§9.1) |
| `K_SECONDARY` | 20 | 2026-08-02 | seeds per secondary arm; ISO-4 uses the same count |
| `SIDAK_M`; $z_\alpha$ | 2; 2.2365 | 2026-08-02 | the two co-primary tests, Šidák-corrected |
| `POWER_STOP` | 0.80 | 2026-08-02 | the minimum design-stage power at the 0.03 band |
| `T_STAR` | 1000 | 2026-08-11 | the training budget in updates, unchanged since 2026-08-03 |
| `GAMMA_T_RETENTION` | 11 | 2026-08-11 | checkpoints kept for Γ(t): updates 500–1000 every 50 |
| evaluation draw | seed 0 × 512 episodes | registered with the grid layout | common to every run; not in the lock registry |
| `PLATEAU_PASS`; `PLATEAU_REVIEW` | 1.0; 1.5 | 2026-08-02 | the convergence check's thresholds, retired 2026-08-11; grade nothing |

The training hyperparameters are identical for every run of §9; the grid passes none on the command line, so the configured defaults apply.

| hyperparameter | value |
|---|---|
| learning rate | 3e-4, constant, no schedule |
| discount γ; GAE λ | 0.99; 0.95 |
| PPO clip ε | 0.2 |
| entropy coefficient; value coefficient | 0.01; 0.5 |
| global gradient-norm clip; Adam ε | 0.5; 1e-5 |
| parallel environments; steps per update | 256; 128 |
| minibatches; epochs | 4; 4 |
| checkpoint interval | 50 updates |
| budget | 32,768 environment steps per update, 32,768,000 per run |

### C Floors

A floor is the standard deviation of a metric over identical reruns at one seed, so it measures nondeterminism alone. Floors are per metric, per GPU, per artifact and per run length; the table lists each one this paper uses, under its study code (key below), with paired floors given as ISO, then JOINT. With four reruns a standard deviation has three degrees of freedom and is uncertain by about ±40 %, and the confirmatory training floors use eight.

| study | GPU, updates | arms or artifact | reruns | floor | use |
|---|---|---|---|---|---|
| M5.1e | RTX 5090, 500 | Medium | 4 | completion 0.0145, survival 0.0129 | the communication studies' Medium bars |
| M5.5 | RTX PRO 6000, 500 | Medium, $R_{\mathrm{comm}}$ 16 | 4 | completion 0.0399, survival 0.0130 | with M5.1e, the per-GPU exhibit (§8.1) |
| M5.5, danger moments | RTX PRO 6000, 500 | Medium | 4 | 27.2 % (sd 0.00182) | voids a 20 % threshold (§8.1) |
| M5.3b | RTX PRO 6000, 500 | High | 4 | survival 0.0621 | reference scale (cross-artifact) |
| M6.0 | RTX PRO 6000 | two code versions | 4 comparisons | 0 of 760 hashes differ in each of 4 comparisons (reference); 1 of 4 comparisons differs (refactored) | the per-artifact exhibit (§8.1) |
| M6.2 | RTX PRO 6000, 500 | ISO, JOINT | 8 | completion 0.0165, 0.0093 | the convergence check |
| M6.2b | RTX PRO 6000, 1000 | ISO, JOINT | 8 | completion 0.0339, 0.0483 | set the design k = 40 |
| G1.2 | RTX PRO 6000, 1000 | ISO, JOINT, sweep at p = 0.5 | 8 | sd(Γ) at k = 40: completion 0.00504, survival 0.00310 | design-stage power |
| re-measured, 2026-09-08 | RTX PRO 6000, 1000 | ISO, JOINT, sweep at p = 0.5 | 8 | the seed rule gave k = 46 | the registered seed rule (§9.1) |
| re-measured on GPU 1 | RTX 5090, 1000 | ISO, JOINT, sweep at p = 0.5 | 8 | completion 0.0587, 0.0577; survival 0.0100, 0.0112 | the seed rule (k = 72); the check against rerun noise |
| High readout | GPU 1's runs, 1000, evaluated on GPU 3 | ISO, JOINT at High | 8 | completion 0.0681, 0.0613; survival 0.0180, 0.0395 | the check against rerun noise at High (§9.2) |
| evaluation | GPU 3 | two checkpoints | 4 | bit-identical | evaluation reproducibility (§11) |
| partial, 2026-08-14 | not recorded, 1000 | ISO, JOINT | 8 + 4 | none reported | provenance only |

The floors of GPU 1 cannot be distinguished from those of the 2026-09-08 re-measurement on an RTX PRO 6000: the 95 % intervals for the standard deviation overlap (ISO completion: [0.0186, 0.0571] on the RTX PRO 6000, [0.0388, 0.1194] on GPU 1). No claim is made that either GPU is less reproducible.

The rule of §8.1 followed four bars whose constants the ruling calls invented. The Coupling-B calibration grid graded its High survival effect against a two-seed spread of 0.0295, below the High floor in the table, and its "strong" grade was retracted (§6.4). The content ablation at Medium applied a floor hard-coded from the four-run Medium floor study on an RTX 5090, not one measured on its own runs. Re-sited at High, the ablation measured its floor first, but a bar set on that floor was out of reach: matching Medium's resolution would take roughly 46 seeds per arm. The denial study set its third condition's threshold below the rerun nondeterminism of its quantity. Those floor data predate the comparison, and the ruling records that a difference above the floor would have left the verdict NOT INERT standing. In the per-artifact exhibit, both versions of the code ran on one GPU, and the two channels that differed were masking diagnostics at High severity.

| code | plain name |
|---|---|
| M3.5 (printed m35) | the Coupling-A calibration grid |
| M4.4 (printed m44) | the Coupling-B calibration grid |
| M5.1e | the four-run Medium floor study on an RTX 5090 |
| M5.3, M5.3b | the content ablation at Medium, and the same ablation at High |
| M5.5 | the denial study |
| M6.0 | the refactor of the environment code |
| M6.2, M6.2b | the confirmatory arms' floor studies at 500 and 1000 updates |
| G1.2 | the grid's launch floor study (2026-08-10) |


### D The frozen analysis plan


The registered constants are in Appendix B. The reading rules follow, quoted from the registration record with their dates: emphasis is the record's own, one indented code line is set inline, and omissions are marked […]. A "§" inside a quotation refers to the record's own sections, and S1–S6 are its labels for the secondary analyses.

**1. The estimand** (T\* ruling, item 2, 2026-08-11):

> **Primary Γ = the confirmatory contrast at MATCHED BUDGET T = 1000, all arms — registered as a fixed-budget claim.**
>
> **"At convergence" is explicitly NOT claimed anywhere.** The paper says **"at matched compute"** throughout, which is also the practitioner-relevant question. […]

**2. Budget robustness** (item 3 of the same ruling; restated for every branch on 2026-08-13):

> The fixed-budget conclusion is reported as **budget-robust iff the sign of Γ is stable over the final half of training**. If the sign is still moving at T, **that instability IS the finding** and is reported as such.

> Mechanism: 11 retained checkpoints, updates 500–1000 at interval 50, confirmatory arms only, **evaluated post-unblind**. Every branch above gains "— budget-robust" or "— sign unstable over the final half" as a suffix, and the suffix is not optional.

**3. The branch-B falsifier** (2026-08-13):

> Branch B is claimable **only if** the completion contrast excludes an effect as large, in standardized units, as the observed survival effect:
>
> `|z_c| + z_α  <  |z_s|,     z = Γ / sd(Γ) per metric`
>
> with `sd(Γ)` the grid's own measured per-arm seed dispersion in the combined form and `z_α = 2.2365` the two-sided Šidák critical value at m = 2. **If it fails, the result is branch C with an asymmetry the design could not resolve — not branch B.**

**4. Test variance and floor** (the frozen analysis plan, amended 2026-08-13):

> **The confirmatory tests and CIs are computed on the GRID'S OWN measured per-arm seed dispersion, not on the floors.** The floors are 8 identical reps at one seed; the grid averages over k distinct seeds, and those are different variances. The floors keep exactly two narrower roles: the **beat-reproducibility hurdle**, and a **design-stage power basis registered as an UPPER BOUND** (§5, superseded note, item 2). […]

Design-stage power is therefore a ceiling. On the grid's launch floor study (an RTX PRO 6000, 2026-08-10), the design-stage MDE₈₀ at k = 40 was 1.55 completion and 0.95 survival points. On the floors of GPU 1, design-stage completion power at a 0.03 effect was 72.2 % at k = 60 and 80.4 % at k = 72; §9.1 gives the realized power.

**5. The inert-share rule** (2026-09-18):

> - Γ and Γ₄ are reported **side by side on every branch**, with B̂ and its CI.
> - If Γ rejects on a co-primary and **Γ₄'s CI on that co-primary includes 0 or its sign is opposite**, the paper states that the effect **does not survive the inert-share correction**, in the abstract-level summary and not only in an appendix. **The branch label does not change** — it is fixed by Γ — but branch A/B text may not describe the effect as a composition effect without that qualifier.
> - If Γ is null and Γ₄ is null, Γ₄ is quoted as a second exclusion bound.
> - If Γ is null and Γ₄ rejects **negative**, it is reported under branch D's framing (matched-budget asymmetry) as a secondary observation, never as a confirmatory finding.
> - **No magnitude threshold on B̂ is introduced**, now or later.

**6. The High readout**, its reading for a null (same ruling):

> - **Γ_H null → an *a fortiori* exclusion**, and the only outcome this readout can establish: *"no gap larger than X at High even where JOINT trained on the evaluated configuration and ISO never saw a composed one."* Quoted as an exclusion with X from the grid's own seed dispersion, never as an absence. […]

The same entry states that the readout "is NOT a held-out test", that a positive $\Gamma_H$ is "NOT separable from in-distribution advantage", and that a negative one is "exploratory".

**7. The 2000-update subsample** (same ruling):

> **What it may be cited for:** whether the differential drift measured at T = 1000 (review §6 item 1: 0.01209 per 100 updates) visibly persists, closes or reverses. **What it may not be cited for:** any claim that Γ "holds" or "vanishes" at T = 2000.

**8. The mediation void rule** (the frozen analysis plan, 2026-08-02):

> **If realized dose does not vary with assigned p, the dose figure has no x-axis and is declared VOID** — registered now, not decided after seeing the first stage.

**9. The pre-unblind rulings** (2026-09-26):

| # | question | RULED |
|---|---|---|
| (i) | what "−" means in the branch table | **Rejection with negative sign** (\|z\| > z_α, Γ < 0). A negative estimate that does not reject is a null. Ratified as built. |
| (ii) | the cell (completion +, survival null), absent from the registered table | **REGISTERED NOW as branch A_c — the founding claim on the founding primary.** […] |
| (iii) | test statistic | **Normal z, z_α = 2.2365**, as the frozen plan wrote; the t critical value is printed, not applied. Ratified as built. |
| (iv) | Γ(t) "sign stable" | **All 11 point estimates, t = 500 … 1000, share one nonzero sign**, per co-primary; t = 1000 is the grid's own eval. Consequence accepted in advance: on a null Γ, chance flips read UNSTABLE. Ratified as built. |
| (v) | Γ₄ sample and threshold | **JOINT k = 72 vs ISO-4 k = 20**, SE `sqrt(s_J²/72 + s_4²/20)`, "rejects" and "CI includes 0" at z_α = 2.2365. (Γ null, Γ₄ rejects positive) stays UNREGISTERED. Ratified as built. |
| (vi) | Γ_H reading | **As (i), at z_α = 2.2365.** Ratified as built. |
| (vii) | primary k | **k = 72 stays primary**; the registered-ladder k = 60 prefix is reported beside it, UNDERPOWERED-flagged. |
| (viii) | re-evaluate the 144 T\* = 1000 checkpoints on the post-unblind card | **YES.** […] |

In (viii), "the post-unblind card" is GPU 3.

**10. The secondary specification** (2026-09-26, after unblinding and before the sweep was read):

> (S1) PAVA + OLS slope CI; (S2) single-hinge breakpoint, UNDERPOWERED iff the CI spans {0.125 … 0.375}; (S3) plane fit, bound = 95 % CI of 0.5·γ_n; (S4) training co-activity over updates 1…1000, VOID iff the first-stage CI contains 0; (S5) the same-card replicate is ADDED, beside Γ₄, unable to change its qualifier; (S6) 95 % intervals, Γ₄′ at z_α. […]

The omitted words name the code version, which identifies the repository.

### E The registered outcome branches

"Positive" and "null" mean rejection or non-rejection at θ\* in the confirmatory family, and "−" means rejection with negative sign (Appendix D, item 9). Branches A–D were registered on 2026-08-13, each with a framing; the registered table's venue-lean column is omitted. $A_c$ was added on 2026-09-26, before unblinding, for a cell the table lacked.

| branch | completion | survival | headline claim, as registered ($A_c$: its registered claims, summarized) |
|---|---|---|---|
| A | + | + | founding registration, verbatim (Γ(θ\*) > 0) |
| B | null | + | composition is paid in **agents**, not task return |
| C | null | null | the instrument, and what it excludes |
| D | − on either co-primary | − on either co-primary | not separable from the matched-budget asymmetry |
| $A_c$ | + | null | the founding claim on the founding primary; the survival null quoted as an exclusion; no asymmetry claim |

The result is branch B, with the inert-share qualifier attached (§9.2).

### F Grid provenance and blinding

The grid was 252 runs from 2026-09-09 to 2026-09-22. Seeds 1–12 of all ten arms (ISO, JOINT and eight secondary arms) ran on an RTX PRO 6000, then seeds 13–20 of all ten arms and 21–46 of ISO and JOINT on GPU 1. The confirmatory artifact holds all 72 seeds of ISO and JOINT on GPU 1: 76 runs executed there and seeds 13–46 copied from the grid. The superseded RTX PRO 6000 seeds enter only a descriptive diagnostic of the GPU effect. Seeds 1–12 of the secondary arms were re-run on GPU 1 (96 runs), so every analysed secondary run is on GPU 1 and Γ₄′ is a same-GPU contrast. ISO-4 and the 2000-update subsample trained on GPU 2, so Γ₄ and B̂ are across GPUs, and the post-unblind evaluations ran on GPU 3.

All arms share seed integers, and seed 0, the floor seed, never enters the grid. Runs are ordered seed-major and chunks end on seed boundaries, so an interruption leaves a smaller balanced design and both arms of a seed share one GPU. Every checkpoint archive's recorded sha256 matched on re-verification on 2026-09-27, 615 of 615. A partial re-measurement of floors on another rented GPU on 2026-08-14 is provenance only.

The grid runner computes no cross-arm quantity, which a unit test asserts along with the seed properties above, and the floor reports print dispersions only. The unblinding script refuses an unflagged artifact or a modified code version, later analysis scripts refuse to run before its log exists, and each log records one run of its stage.

### G Gamma over the final half of training

**Sign unstable over the final half**, on both co-primaries: neither meets the registered rule that all 11 point estimates share one sign (Appendix D, items 2 and 9). Values are rates, and the Šidák-corrected intervals are registered at update 1000 and descriptive before it. Checkpoints before update 1000 were evaluated on GPU 3; update 1000 is the grid's own evaluation, and re-evaluating it on GPU 3 leaves every sign unchanged (cross-GPU agreement: §11).

Completion, k = 72 per arm:

| update | Γ(t) | sd(Γ) | Šidák CI | sign |
|---|---|---|---|---|
| 500 | +0.0017 | 0.00321 | [−0.0055, +0.0089] | + |
| 550 | −0.0017 | 0.00353 | [−0.0096, +0.0062] | − |
| 600 | +0.0018 | 0.00362 | [−0.0063, +0.0099] | + |
| 650 | +0.0015 | 0.00481 | [−0.0093, +0.0122] | + |
| 700 | −0.0037 | 0.00470 | [−0.0142, +0.0068] | − |
| 750 | −0.0147 | 0.00610 | [−0.0283, −0.0010] | − |
| 800 | −0.0035 | 0.00677 | [−0.0187, +0.0116] | − |
| 850 | −0.0053 | 0.00729 | [−0.0216, +0.0110] | − |
| 900 | −0.0039 | 0.00843 | [−0.0228, +0.0149] | − |
| 950 | −0.0016 | 0.01021 | [−0.0245, +0.0212] | − |
| 1000 | −0.0173 | 0.01068 | [−0.0412, +0.0066] | − |

Survival rate, k = 72 per arm:

| update | Γ(t) | sd(Γ) | Šidák CI | sign |
|---|---|---|---|---|
| 500 | +0.0022 | 0.00228 | [−0.0029, +0.0073] | + |
| 550 | −0.0037 | 0.00220 | [−0.0086, +0.0013] | − |
| 600 | −0.0027 | 0.00232 | [−0.0078, +0.0025] | − |
| 650 | +0.0011 | 0.00242 | [−0.0043, +0.0065] | + |
| 700 | +0.0031 | 0.00235 | [−0.0021, +0.0084] | + |
| 750 | +0.0036 | 0.00255 | [−0.0021, +0.0093] | + |
| 800 | +0.0020 | 0.00232 | [−0.0032, +0.0072] | + |
| 850 | +0.0018 | 0.00234 | [−0.0034, +0.0071] | + |
| 900 | +0.0056 | 0.00231 | [+0.0004, +0.0108] | + |
| 950 | +0.0083 | 0.00219 | [+0.0034, +0.0132] | + |
| 1000 | +0.0096 | 0.00216 | [+0.0047, +0.0144] | + |

### H The secondary design

Everything here is secondary, with 95 % intervals bootstrapped over seeds within arm (B = 2000), conditional on the common evaluation draw and not family-corrected. Each arm has k = 20 seeds on GPU 1 with δ off. With μ, p and ν as in §9.1, the triangle gives $\nu = 1 - 2\mu + p$, and the arm names are the labels of Figure 13's table view.

| arm | μ | p | ν | survival | completion |
|---|---|---|---|---|---|
| `sweep_c50_p000` | 0.5 | 0 | 0 | 0.9241 | 0.7847 |
| `sweep_c50_p125` | 0.5 | 0.125 | 0.125 | 0.9249 | 0.7775 |
| `sweep_c50_p250` | 0.5 | 0.25 | 0.25 | 0.9261 | 0.7797 |
| `sweep_c50_p375` | 0.5 | 0.375 | 0.375 | 0.9264 | 0.7656 |
| `sweep_c50_p500` | 0.5 | 0.5 | 0.5 | 0.9289 | 0.7749 |
| `ident_c40_p000` | 0.4 | 0 | 0.2 | — | — |
| `ident_c40_p200` | 0.4 | 0.2 | 0.4 | — | — |
| `ident_c40_p400` | 0.4 | 0.4 | 0.6 | — | — |
| ISO-4 (GPU 2) | 0.5 | 0 | 0 | 0.9256 | 0.7726 |

The p = 0 sweep arm carries exactly ISO-4's training mixture.

| estimate (points) | survival | completion |
|---|---|---|
| sweep slope per unit p (labelled “dose slope”; separate fit) | +0.89 [−0.33, +2.11] | −2.51 [−9.43, +4.12] |
| sweep endpoint, p = 0.5 minus p = 0 | +0.48 [−0.21, +1.17] | −0.97 [−4.82, +2.87] |
| γ<sub>p</sub>, the co-occurrence slope, per unit p | +3.26 [+1.37, +5.02] | +2.69 [−6.75, +12.45] |
| γ<sub>n</sub>, the fire-only-share slope, per unit ν | −2.37 [−4.19, −0.57] | −6.52 [−15.34, +2.42] |
| bound, 0.5 γ<sub>n</sub> | −1.19 [−2.10, −0.28] | −3.26 [−7.67, +1.21] |
| change point in p (labelled “knee”) | 0.375 [0.125, 0.375], UNDERPOWERED | 0.375 [0.125, 0.375], UNDERPOWERED |
| plane prediction of JOINT − ISO-4 (γ<sub>p</sub> × 1) | §9.2 | +2.69; γ<sub>p</sub>'s interval contains both measured values |

The plane $y = \gamma_0 + \gamma_p p + \gamma_n \nu$ is a seed-level ordinary least squares (OLS) fit over all eight arms, and the bound, the fire-only share's part of the sweep's endpoint change, excludes zero on survival. The sweep slope is a separate seed-level OLS fit over the five sweep arms, with an isotonic fit (PAVA) giving its monotone shape. The plane's slope along the sweep is $\gamma_p + \gamma_n$, so the two need not agree, and on completion they do not. The change point is the breakpoint of the best single-hinge fit. Linearity is assumed and checked only coarsely: arm-mean residuals lie within ±0.4 SE on survival and ±1.1 SE on completion, 8 points for 3 parameters.

Per-coupling frequency, co-occurrence and active share cannot all be held fixed on the triangle. Floors exist only for the sweep's p = 0.5 arm: the other sweep arms assume that floor, and the identification arms are ungraded. The counter's realized count is endogenous, so nothing here is its causal effect, and mediation is VOID (§9.2).

### I Trained-policy episodes

Figures I1 and I2 show one episode of each confirmatory arm, separately, chosen by a rule fixed before any render: θ\*, episode key 0, stochastic actions, training seed 1 at update 1000. Each opens at step 128 of 256. They illustrate the environment under a trained policy and grade nothing.

<figure class="l-page">
  <iframe src="{{ 'assets/html/submission/explorer_thetastar_iso_s1_T1000_ep0.html' | relative_url }}" width="100%" height="700" style="border:none" title="Episode explorer, ISO policy, training seed 1" loading="lazy"></iframe>
  <figcaption><strong>Figure I1.</strong> One episode of the ISO policy at θ&#42;. The map is environment state, the smoke field ρ included. Selecting an agent shows its observation as produced (labelled obs v3: the masking observation, §6.1), the true cells, and the probability τ that each was seen. It cannot compare training protocols. <span class="figure-note">Status: illustrative · grades nothing · Interact: play, step, click an agent.</span></figcaption>
</figure>

<div class="print-companion">
{% include figure.html path="assets/img/submission/explorer_thetastar_iso_s1_T1000_ep0_static.png" class="img-fluid" alt="Maps of one ISO-policy episode at its start, middle and end, with one agent's observation, the true state of the same cells, and the probability each cell was seen" caption="Static companion of Figure I1 for the printed PDF." %}
</div>

Figure I2 shows the JOINT policy's episode under the same rule. One episode of one seed cannot carry a contrast that §9.2 measures over 72 seeds per arm and 512 evaluation episodes.

<figure class="l-page">
  <iframe src="{{ 'assets/html/submission/explorer_thetastar_joint_s1_T1000_ep0.html' | relative_url }}" width="100%" height="700" style="border:none" title="Episode explorer, JOINT policy, training seed 1" loading="lazy"></iframe>
  <figcaption><strong>Figure I2.</strong> One episode of the JOINT policy at θ&#42;, with the layers and panels of Figure I1; only the observation panel shows what the selected agent perceives. It cannot compare training protocols. <span class="figure-note">Status: illustrative · grades nothing · Interact: as Figure I1.</span></figcaption>
</figure>

<div class="print-companion">
{% include figure.html path="assets/img/submission/explorer_thetastar_joint_s1_T1000_ep0_static.png" class="img-fluid" alt="Maps of one JOINT-policy episode at its start, middle and end, with one agent's observation, the true state of the same cells, and the probability each cell was seen" caption="Static companion of Figure I2 for the printed PDF." %}
</div>
